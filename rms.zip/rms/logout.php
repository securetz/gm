<?php 
//include 'database/dbcon.php';
$con=mysqli_connect("localhost","root","josh","rms") ;
	session_start();
	session_destroy();
	header("Location:login.php");
?>

