<?php
session_start();
$con = mysqli_connect("localhost", "root", "josh", "rms");

if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location:index.php?lmsg=true');
    exit;
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <link rel="icon" type="image/png" href="images/favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta http-equiv="refresh" content="30">

    <title>RMS | Sales </title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport'/>
    <meta name="viewport" content="width=device-width"/>
    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>
    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>
    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet"/>
    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet"/>
    <link type="text/css" href="vendor/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" href="vendor/css/bootstrap-table.css" rel="stylesheet">
    <link type="text/css" href="vendor/css/font-awesome.css" rel="stylesheet">
    <!-- Bootstrap core CSS-->
    <!-- Custom fonts for this template-->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="vendor/css/sb-admin.css" rel="stylesheet">
    <style>
        #chart-container {
            width: 95%;
            height: auto;
            padding-left: 2cm;
        }
    </style>
</head>
<body>
<div class="wrapper">
    <div class="sidebar" data-color="blue" data-image="assets/img/sidebar-5.jpg">

        <!--Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
            Tip 2: you can also add an image using data-image tag-->

        <div class="sidebar-wrapper">
            <div class="logo">
                <h5>Revenue Management System</h5>
            </div>
            <ul class="nav">
                <li class="active">
                    <a href="dashboard.php">
                        <i class="pe-7s-home"></i>
                        <p>DashBoard</p>
                    </a>
                </li>
                <li class="active">
                    <a href="sales.php">
                        <i class="pe-7s-note2"></i>
                        <p>General Sales</p>
                    </a>
                </li>
                <li class="active">
                    <a href="#">
                        <i class="pe-7s-note"></i>
                        <p>Client Payment</p>
                    </a>
                </li>
                <li class="active">
                    <a href="#">
                        <i class="pe-7s-news-paper"></i>
                        <p> Branches</p>
                    </a>
                </li>
                <?php
                //only visible to admin
                if ($_SESSION['user_role_id'] == 1) {
                    ?>
                    <li class=" active nav-item" data-toggle="tooltip" data-placement="right" title="Components">
                        <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse"
                           href="#collapseComponents"
                           data-parent="#exampleAccordion">
                            <i class="pe-7s-config"></i>
                            <p>Management</p>
                        </a>
                        <ul class="sidenav-second-level collapse" id="collapseComponents">
                            <li class="active">
                                <a href="manage_client.php">
                                    <i class="pe-7s-id"></i>
                                    <p>Client</p>
                                </a>
                            </li>
                            <li class="active">
                                <a href="manage_station.php">
                                    <i class="pe-7s-diamond"></i>
                                    <p>Station</p>
                                </a>
                            </li>
                            <li class="active">
                                <a href="manage_branches.php">
                                    <i class="pe-7s-way"></i>
                                    <p>Branches</p>
                                </a>
                            </li>
                            <li class="active">
                                <a href="manage_rev_categories.php">
                                    <i class="pe-7s-wallet"></i>
                                    <p>Categories</p>
                                </a>
                            </li>
                            <li class="active">
                                <a href="manage_clerks.php">
                                    <i class="pe-7s-settings"></i>
                                    <p>Manage Clerks</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php
                }
                ?>
                <li class="active">
                    <a href="#">
                        <i class="pe-7s-cash"></i>
                        <p>General Reports</p>
                    </a>
                </li>
                <li class="active">
                    <a href="#">
                        <i class="pe-7s-settings"></i>
                        <p>Settings</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a>
                                <i class="fa fa-dashboard"></i>
                                <p class="hidden-lg hidden-md">Dashboard</p>
                            </a>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active">
                            <a>
                                <p>Admin Email:
                                    <?php echo $_SESSION['email']; ?>
                                </p>
                            </a>
                        </li>
                        <li class="active">
                            <a href="index.php">
                                <p>Log out</p>
                            </a>
                        </li>
                        <li class="separator hidden-lg"></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="content">
            <div class="container-fluid">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a style="text-decoration: none">General Sales</a>
                    </li>
                    <li class="breadcrumb-item active">All Sales Reports</li>
                </ol>
                <hr>
                <div class="panel-heading text-center">
                    <span><strong>ALL SALES REVENUE COLLECTION</strong></span>
                </div>
                <table class="table table-hover table-bordered">
                    <thead>
                    <tr class="info">
                        <th>CATEGORY</th>
                        <th>AMOUNT</th>
                    </tr>
                    </thead>
                    <?php
                    $query = mysqli_query($con, "SELECT SUM(amount_paid) AS amount_paid_today FROM sales;");
                    while ($row1 = mysqli_fetch_array($query)) {
                        $amount_paid = $row1['amount_paid_today'];
                        ?>
                        <tr>
                            <td>TOTAL SALES</td>
                            <td class="active"><a>TZS <?php echo $amount_paid ?>/=</a></td>
                        </tr>
                    <?php } ?>
                </table>
                <br>
                <h6 class="text-center">COLLECTION BY REVENUE CATEGORY</h6>
                <table class="table table-hover table-striped table-bordered">
                    <thead>
                    <tr class="info">
                        <th>REVENUE CATEGORY</th>
                        <th>AMOUNT</th>
                        <th>DATE</th>
                    </tr>
                    </thead>
                    <tfoot>
                    <tr class="info">
                        <th>REVENUE CATEGORY</th>
                        <th>AMOUNT</th>
                        <th>DATE</th>
                    </tr>
                    </tfoot>
                    <?php
                    $query1 = "SELECT *  FROM revenue_category_amount GROUP BY revenue_name ORDER BY total_amount DESC ;";
                    $result1 = mysqli_query($con, $query1);

                    while ($row = mysqli_fetch_array($result1)) {
                        $revenue = $row['revenue_name'];
                        // $branch_name = $row['amount_paid'];
                        $date = date("M. d, Y");
                        ?>
                        <tr>
                            <td><?php echo $revenue; ?></td>
                            <td><a><?php echo $row['total_amount']; ?> /=</a></td>
                            <td><?php echo $date; ?></td>

                        </tr>
                    <?php }  //End of while loop
                    ?>
                </table>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                    </li>
                </ol>
                <div class="card mb-3">
                    <div class="panel-info text-center">
                        <br>
                        <span>COLLECTION BY REVENUE CATEGORY BAR CHART PRESENTATION</span>
                    </div>
                    <hr>
                    <div>
                        <div class="container" id="chart-container">
                            <canvas id="mycanvas"></canvas>
                        </div>
                    </div>
                    <hr>
                    <div class="card-footer small text-muted">
                        <strong> <?php date_default_timezone_set('Africa/Dar_es_Salaam');
                            echo "Last Data Update at  " . date("H:i: d/m/Y") . "<br>"; ?></strong>
                    </div>
                </div>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                    </li>
                </ol>
                <!-- Example DataTables Card-->
                <div class="card mb-3">
                    <div class="card-header">
                        <i class="fa fa-table"></i>Sales Records
                    </div>
                    <div class="panel-heading text-center">
                        <span>ALL SALES REVENUE RECORDS</span>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover table-striped table-bordered" id="dataTable" width="100%"
                                   cellspacing="0">
                                <thead>
                                <tr class="info">
                                    <th>SALES ID</th>
                                    <th>CUSTOMER NAME</th>
                                    <th>AMOUNT PAID</th>
                                    <th>DATE PAID</th>
                                    <th>REVENUE NAME</th>
                                    <th>CLERK NAME</th>
                                    <th>BRANCH NAME</th>
                                    <th>STATION NAME</th>
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th>SALES ID</th>
                                    <th>CUSTOMER NAME</th>
                                    <th>AMOUNT PAID</th>
                                    <th>DATE PAID</th>
                                    <th>REVENUE NAME</th>
                                    <th>CLERK NAME</th>
                                    <th>BRANCH NAME</th>
                                    <th>STATION NAME</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                <?php
                                $query1 = "SELECT * FROM all_sales_records ORDER BY sales_id DESC ;";
                                $result1 = mysqli_query($con, $query1);

                                while ($row = mysqli_fetch_assoc($result1)) {
                                    $sales_id = $row['sales_id'];
                                    $name = $row['customer_name'];
                                    $amount = $row['amount_paid'];
                                    $date = $row['date_paid'];
                                    $station = $row['revenue_name'];
                                    $branch = $row['clerk_name'];
                                    $clerk = $row['branch_name'];
                                    $revenue = $row['station_name'];

                                    ?>
                                    <tr>
                                        <td><a><?php echo $sales_id; ?></a></td>
                                        <td><?php echo $name; ?></td>
                                        <td><a><?php echo $amount; ?>/=</a></td>
                                        <td><?php echo $date; ?></td>
                                        <td><a><?php echo $station; ?></a></td>
                                        <td><?php echo $branch; ?></td>
                                        <td><a><?php echo $clerk; ?></a></td>
                                        <td><?php echo $revenue; ?></td>

                                    </tr>
                                <?php }  //End of while loop
                                ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer class="panel-footer">
            <div class="container-fluid">
                <p class="copyright pull-right">Copyright &copy;
                    <script>document.write(new Date().getFullYear())</script>
                    WebTechnologoies
                </p>
            </div>
        </footer>
        <script>
            $(document).ready(function () {
                $('#dataTable').DataTable();
            });
        </script>
    </div>
</div>

<script type="text/javascript" src="chart/js/jquery.min.js"></script>
<script type="text/javascript" src="chart/js/Chart.min.js"></script>
<script type="text/javascript" src="chart/js/all_sales_data.js"></script>
<script type="text/javascript" src="chart/js/Chart.min.js"></script>
<script type="text/javascript" src="chart/js/all_sales_data.js"></script>
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<!-- Page level plugin JavaScript-->
<script src="vendor/datatables/jquery.dataTables.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.js"></script>
<!-- Custom scripts for all pages-->
<script src="vendor/js/sb-admin.min.js"></script>
<!-- Custom scripts for this page-->
<script src="vendor/js/sb-admin-datatables.min.js"></script>

</body>
</html>

