
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->

    <script src="../js/ie-emulation-modes-warning.js"></script>
    <link href="../css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <!-- Bootstrap core CSS     -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet"/>
    <!-- Animation library for notifications   -->
    <link href="../assets/css/animate.min.css" rel="stylesheet"/>
    <!--  Light Bootstrap Table core CSS    -->
    <link href="../assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet'>
    <link href="../assets/css/pe-icon-7-stroke.css" rel="stylesheet"/>
    <link type="text/css" href="../vendor/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" href="../vendor/css/bootstrap-table.css" rel="stylesheet">
    <link type="text/css" href="../vendor/css/font-awesome.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <!-- Bootstrap core CSS-->
    <!-- Custom fonts for this template -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Page level plugin CSS-->
    <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="../vendor/css/sb-admin.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
</head>
<body>
<div class="wrapper">
    <div class="sidebar" data-color="blue" data-image="assets/img/sidebar-5.jpg">

        <!--Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
            Tip 2: you can also add an image using data-image tag-->

        <div class="sidebar-wrapper">
            <div class="logo">
                <h5>Revenue Management System</h5>
            </div>
            <ul class="nav">
                <li class="active">
                    <a href="../dashboard.php">
                        <i class="pe-7s-home"></i>
                        <p>DashBoard</p>
                    </a>
                </li>
                <li class="active">
                    <a href="../sales.php">
                        <i class="pe-7s-note2"></i>
                        <p>General Sales</p>
                    </a>
                </li>
                <li class="active">
                    <a href="#">
                        <i class="pe-7s-note"></i>
                        <p>Client Payment</p>
                    </a>
                </li>
                <li class="active">
                    <a href="#">
                        <i class="pe-7s-news-paper"></i>
                        <p> Branches</p>
                    </a>
                </li>
                <?php
                //only visible to admin
                //if ($_SESSION['user_role_id'] == 1) {
                ?>
                <li class=" active nav-item " data-toggle="tooltip" data-placement="right" title="Components">
                    <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse"
                       href="#collapseComponents"
                       data-parent="#exampleAccordion">
                        <i class="pe-7s-config"></i>
                        <p>Management</p>
                    </a>
                    <ul class="sidenav-second-level collapse" id="collapseComponents">
                        <li class="active">
                            <a href="../manage_client.php">
                                <i class="pe-7s-id"></i>
                                <p>Client</p>
                            </a>
                        </li>
                        <li class="active">
                            <a href="../manage_station.php">
                                <i class="pe-7s-diamond"></i>
                                <p>Station</p>
                            </a>
                        </li>
                        <li class="active">
                            <a href="../manage_branches.php">
                                <i class="pe-7s-way"></i>
                                <p>Branches</p>
                            </a>
                        </li>
                        <li class="active">
                            <a href="../manage_rev_categories.php">
                                <i class="pe-7s-wallet"></i>
                                <p>Categories</p>
                            </a>
                        </li>
                        <li class="active">
                            <a href="../manage_clerks.php">
                                <i class="pe-7s-settings"></i>
                                <p>Manage Clerks</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="active">
                    <a href="#">
                        <i class="pe-7s-cash"></i>
                        <p>General Reports</p>
                    </a>
                </li>
                <li class="active">
                    <a href="#">
                        <i class="pe-7s-settings"></i>
                        <p>Settings</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>
<div class="main-panel">
<nav class="navbar navbar-default navbar-fixed">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand">Dashboard</a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-left">
                <li>
                    <a>
                        <i class="fa fa-dashboard"></i>
                        <p class="hidden-lg hidden-md">Dashboard</p>
                    </a>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li class="active">
                    <a>
                        <p>Admin Email:

                        </p>
                    </a>
                </li>
                <li class="active">
                    <a href="../index.php">
                        <p>Log out</p>
                    </a>
                </li>
                <li class="separator hidden-lg"></li>
            </ul>
        </div>
    </div>
</nav>
<div class="content">
    <div class="container-fluid">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a style="text-decoration: none">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Add New Client</li>
        </ol>
        <!-- Example DataTables Card-->
        <div class="card mb-3">
            <div class="card-body">
                <div class="container" style="padding-top: 1cm">
                    <div class="row centered-form">
                        <div class="col-xs-10 ">
                            <div class="panel panel-default">
                                <div class="message"><?php if (isset($message)) {
                                        echo $message;
                                    } ?></div>
                                <div class="panel-heading">
                                    <h3 class="panel-title">Please add client information</h3>
                                </div>
                                <div class="panel-body">
                                    <form method="post" autocomplete="off" action="create_client.php">
                                        <div class="row">
                                            <div class="col-xs-6 col-sm-6 col-md-6">
                                                <div class="form-group">
                                                    <input type="text" name="first_name" id="firstname"
                                                           class="form-control input-sm"
                                                           placeholder="First Name">
                                                </div>
                                            </div>
                                            <div class="col-xs-6 col-sm-6 col-md-6">
                                                <div class="form-group">
                                                    <input type="text" name="lastname" id="lastname"
                                                           class="form-control input-sm"
                                                           placeholder="last name">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-xs-6 col-sm-6 col-md-6">
                                                <div class="form-group">
                                                    <input type="password" name="password" id="password" autocomplete="new-password"
                                                           class="form-control input-sm" placeholder="Password">
                                                </div>
                                            </div>
                                            <div class="col-xs-6 col-sm-6 col-md-6">
                                                <div class="form-group">
                                                    <input type="email" name="email" id="address" autocomplete="new-email"
                                                           class="form-control input-sm" placeholder="Email">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-xs-6 col-sm-6 col-md-6">
                                                <div class="form-group">
                                                    <input type="tel" name="contact" id="contact"
                                                           class="form-control input-sm"
                                                           placeholder="contact">
                                                </div>
                                            </div>
                                            <div class="col-xs-6 col-sm-6 col-md-6">
                                                <div class="form-group">
                                                    <input type="date" name="date_created" id="date"
                                                           class="form-control input-sm" placeholder="Date">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-xs-6 col-sm-6 col-md-6">
                                                <div class="form-group">
                                                    <input type="number" min="0" name="admin_id" id="client_id"
                                                           class="form-control input-sm"
                                                           placeholder="Admin ID">
                                                </div>
                                            </div>
                                        </div>

                                        <input type="submit" name="submit" value="Add" class="btn btn-info">

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
        <footer class="panel-footer">
            <div class="container-fluid">
                <p class="copyright pull-right">Copyright &copy;
                    <script>document.write(new Date().getFullYear())</script>
                    WebTechnologoies
                </p>
            </div>
        </footer>
        <script>
            $(document).ready(function () {
                $('#dataTable').DataTable();
            });
        </script>
    </div>
</div>
<script type="text/javascript" src="../chart/js/jquery.min.js"></script>
<script type="text/javascript" src="../chart/js/Chart.min.js"></script>
<script type="text/javascript" src="../chart/js/app.js"></script>
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="../vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/css/buttons.dataTables.min.css"></script>
<!-- Page level plugin JavaScript-->
<!--<script src="vendor/datatables/jquery.dataTables.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.js"></script>  -->
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
</body>
</html>