<?php
session_start();
$con=mysqli_connect("localhost","root","josh","rms") ;
if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location:index.php?lmsg=true');
    exit;
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1,chrome=1"/>
    <meta http-equiv="refresh" content="30">
    <link rel="icon" href="images/favicon.ico">

    <title>RMS | Dashboard </title>
    <script src="js/ie-emulation-modes-warning.js"></script>
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>
    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet"/>
    <link type="text/css" href="vendor/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" href="vendor/css/bootstrap-table.css" rel="stylesheet">
    <link type="text/css" href="vendor/css/font-awesome.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <!-- Bootstrap core CSS-->
    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="vendor/css/sb-admin.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!-- SCRIPT AND CSS FOR CRUD-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
</head>
<body>
<div class="wrapper">
    <div class="sidebar" data-color="blue" data-image="assets/img/sidebar-5.jpg">

        <!--Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
            Tip 2: you can also add an image using data-image tag-->

        <div class="sidebar-wrapper">
            <div class="logo">
                <h5>Revenue Management System</h5>
            </div>
            <ul class="nav">
                <li class="active">
                    <a href="dashboard.php">
                        <i class="pe-7s-home"></i>
                        <p>DashBoard</p>
                    </a>
                </li>
                <li class="active">
                    <a href="sales.php">
                        <i class="pe-7s-note2"></i>
                        <p>General Sales</p>
                    </a>
                </li>
                <li class="active">
                    <a href="#">
                        <i class="pe-7s-note"></i>
                        <p>Client Payment</p>
                    </a>
                </li>
                <li class="active">
                    <a href="#">
                        <i class="pe-7s-news-paper"></i>
                        <p> Branches</p>
                    </a>
                </li>
                <?php
                //only visible to admin
                if ($_SESSION['user_role_id'] == 1) {
                    ?>
                    <li class=" active nav-item" data-toggle="tooltip" data-placement="right" title="Components">
                        <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse"
                           href="#collapseComponents"
                           data-parent="#exampleAccordion">
                            <i class="pe-7s-config"></i>
                            <p>Management</p>
                        </a>
                        <ul class="sidenav-second-level collapse" id="collapseComponents">
                            <li class="active">
                                <a href="#">
                                    <i class="pe-7s-id"></i>
                                    <p>Client</p>
                                </a>
                            </li>
                            <li class="active">
                                <a href="manage_station.php">
                                    <i class="pe-7s-diamond"></i>
                                    <p>Station</p>
                                </a>
                            </li>
                            <li class="active">
                                <a href="manage_branches.php">
                                    <i class="pe-7s-way"></i>
                                    <p>Branches</p>
                                </a>
                            </li>
                            <li class="active">
                                <a href="manage_rev_categories.php">
                                    <i class="pe-7s-wallet"></i>
                                    <p>Categories</p>
                                </a>
                            </li>
                            <li class="active">
                                <a href="manage_clerks.php">
                                    <i class="pe-7s-settings"></i>
                                    <p>Manage Clerks</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php
                }
                ?>
                <li class="active">
                    <a href="#">
                        <i class="pe-7s-cash"></i>
                        <p>General Reports</p>
                    </a>
                </li>
                <li class="active">
                    <a href="#">
                        <i class="pe-7s-settings"></i>
                        <p>Settings</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a>
                                <i class="fa fa-dashboard"></i>
                                <p class="hidden-lg hidden-md">Dashboard</p>
                            </a>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active">
                            <a>
                                <p>Admin Email:
                                    <?php echo $_SESSION['email']; ?>
                                </p>
                            </a>
                        </li>
                        <li class="active">
                            <a href="index.php">
                                <p>Log out</p>
                            </a>
                        </li>
                        <li class="separator hidden-lg"></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="content">
            <div class="container-fluid">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a style="text-decoration: none">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">Client Management</li>
                </ol>
                <div class="col-md-12">
                    <div class="card">
                        <div class="header modal-header" style="text-align: center">
                            <h5>CLIENT MANAGEMENT PANEL</h5>
                        </div>
                        <div class="header clearfix">
                            <a href="client/create_client.php" class="btn btn-success pull-right">Add New Client</a>
                        </div>
                        <div class="content table-responsive table-full-width">
                            <table class="table table-hover table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th class="info">CLIENT ID</th>
                                    <th class="info">FIRST NAME</th>
                                    <th class="info">LAST NAME</th>
                                    <th class="info">EMAIL</th>
                                    <th class="info">CONTACT</th>
                                    <th class="info">ACTIONS</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <?php
                                    $query = "SELECT client_id, first_name,last_name, email,contact FROM client";//select query for viewing users.
                                    $run = mysqli_query($con, $query);//here run the sql query.

                                    while ($row = mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
                                    {
                                    $client_id = $row[0];
                                    $first_name = $row[1];
                                    $last_name = $row[2];
                                    $email = $row[3];

                                    ?>
                                </tr>
                                <tr>
                                    <!--here showing results in the table -->
                                    <td><?php echo $client_id; ?></td>
                                    <td><?php echo $first_name; ?></td>
                                    <td><?php echo $last_name; ?></td>
                                    <td><?php echo $email; ?></td>
                                    <td><a><?php echo $row['contact'] ?></a></td>
                                    <td>
                                        <a href='client/read_client.php?id=' title='View Record'
                                           data-toggle='tooltip'><span class='glyphicon glyphicon-eye-open'></span></a>
                                        <a href='client/update_client.php?id=' title='Update Record'
                                           data-toggle='tooltip'><span class='glyphicon glyphicon-pencil'></span></a>
                                        <a href='client/delete_client.php?id=' title='Delete Record'
                                           data-toggle='tooltip'><span class='glyphicon glyphicon-trash'></span></a>
                                    </td>
                                </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            $(document).ready(function () {
                $('#dataTable').DataTable();
            });
        </script>
        <footer class="panel-footer">
            <div class="container-fluid">
                <p class="copyright pull-right">Copyright &copy;
                    <script>document.write(new Date().getFullYear())</script>
                    WebTechnologoies
                </p>
            </div>
        </footer>
    </div>
</div>
<script type="text/javascript" src="chart/js/jquery.min.js"></script>
<script type="text/javascript" src="chart/js/Chart.min.js"></script>
<script type="text/javascript" src="chart/js/app.js"></script>
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/css/buttons.dataTables.min.css"></script>
<!-- Page level plugin JavaScript-->
<!--<script src="vendor/datatables/jquery.dataTables.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.js"></script>  -->
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<!--Custom scripts for all pages
<script src="vendor/js/sb-admin.min.js"></script>
<!--Custom scripts for this page
<script src="vendor/js/sb-admin-datatables.min.js"></script>  -->
</body>
</html>

