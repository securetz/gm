-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2018 at 07:09 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rms`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `admin_id` int(10) NOT NULL,
  `first_name` varchar(25) COLLATE utf8_bin NOT NULL,
  `last_name` varchar(25) COLLATE utf8_bin NOT NULL,
  `password` varchar(50) COLLATE utf8_bin NOT NULL,
  `email` varchar(25) COLLATE utf8_bin NOT NULL,
  `contact` varchar(14) COLLATE utf8_bin NOT NULL,
  `status` varchar(50) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`admin_id`, `first_name`, `last_name`, `password`, `email`, `contact`, `status`) VALUES
(1, 'joshua', 'nelson', '1234567', 'nelson@gmail.com', '0655747073', 'active');

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_sales_records`
-- (See below for the actual view)
--
CREATE TABLE `all_sales_records` (
`sales_id` int(11)
,`customer_name` varchar(20)
,`amount_paid` int(100)
,`date_paid` date
,`revenue_name` varchar(50)
,`clerk_name` varchar(101)
,`branch_name` varchar(50)
,`station_name` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` int(20) NOT NULL,
  `branch_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `date_created` date NOT NULL,
  `station_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `branch_name`, `date_created`, `station_id`) VALUES
(1, 'IKWIRIRI STAND', '2018-02-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `clerk`
--

CREATE TABLE `clerk` (
  `clerk_id` int(20) NOT NULL,
  `first_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `last_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(50) COLLATE utf8_bin NOT NULL,
  `contact` varchar(14) COLLATE utf8_bin NOT NULL,
  `date_created` date NOT NULL,
  `type` varchar(50) COLLATE utf8_bin NOT NULL,
  `station_id` int(20) NOT NULL,
  `branch_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `clerk`
--

INSERT INTO `clerk` (`clerk_id`, `first_name`, `last_name`, `password`, `email`, `contact`, `date_created`, `type`, `station_id`, `branch_id`) VALUES
(1, 'Rajabu', 'Shaban', '', 'rajabshabani21@gmail.com', '', '2018-02-22', 'employee', 1, 1),
(2, 'Abdulrahman', 'Rajab', '', 'abdulrahmanirajab21@gmail.com', '', '2018-02-22', 'employee', 1, 1),
(3, 'Ramadhani ', 'Said', '', 'saidiramadhani330@gmail.com', '', '2018-02-22', 'employee', 1, 1),
(5, 'Faridi', 'Hasan', '', 'faridihasani00@gmail.com', '', '2018-02-22', 'employee', 1, 1),
(6, 'Juma', 'Ungando', '', 'jumaungando@gmail.com', '', '2018-02-22', 'employee', 1, 1),
(7, 'Kassim', 'Hassan', '', 'kassimhassan@gmail.com', '', '2018-02-22', 'employee', 1, 1),
(8, 'Hasan', 'Khamis', '', 'khamishasan70@gmail.com', '07783898392', '2018-02-21', 'employee', 1, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `clerk_amount_collected_today`
-- (See below for the actual view)
--
CREATE TABLE `clerk_amount_collected_today` (
`clerk_name` varchar(101)
,`sum(amount_paid)` decimal(65,0)
);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `client_id` int(20) NOT NULL,
  `first_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `last_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(50) COLLATE utf8_bin NOT NULL,
  `email` varchar(50) COLLATE utf8_bin NOT NULL,
  `contact` varchar(14) COLLATE utf8_bin NOT NULL,
  `date_created` date NOT NULL,
  `admin_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`client_id`, `first_name`, `last_name`, `password`, `email`, `contact`, `date_created`, `admin_id`) VALUES
(1, 'Godfrey', 'Godfrey', '', 'godfrey@gmail.com', '99597939', '2018-02-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `revenue_category`
--

CREATE TABLE `revenue_category` (
  `revenue_id` int(20) NOT NULL,
  `revenue_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `date_created` date NOT NULL,
  `station_id` int(20) NOT NULL,
  `branch_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `revenue_category`
--

INSERT INTO `revenue_category` (`revenue_id`, `revenue_name`, `date_created`, `station_id`, `branch_id`) VALUES
(1, 'BODABODA', '2018-02-21', 1, 1),
(2, 'HUDUMA YA CAR WASH', '2018-02-21', 1, 1),
(3, 'MAJI', '2018-02-21', 1, 1),
(4, 'WAFANYABIASHARA', '2018-02-21', 1, 1),
(5, 'BUS', '2018-02-21', 1, 1),
(6, 'KULAZA MAGARI', '2018-02-21', 1, 1),
(7, 'KUPAKI USAFIRI', '2018-02-21', 1, 1),
(8, 'HUDUMA YA CHOO', '2018-02-21', 1, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `revenue_category_amount`
-- (See below for the actual view)
--
CREATE TABLE `revenue_category_amount` (
`revenue_name` varchar(50)
,`total_amount` decimal(65,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `revenue_category_today_sales`
-- (See below for the actual view)
--
CREATE TABLE `revenue_category_today_sales` (
`revenue_name` varchar(50)
,`amount_paid` decimal(65,0)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `revenue_id_amount`
-- (See below for the actual view)
--
CREATE TABLE `revenue_id_amount` (
`revenue_id` int(20)
,`amount_paid` decimal(65,0)
);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL,
  `customer_name` varchar(20) COLLATE utf8_bin NOT NULL,
  `amount_paid` int(100) NOT NULL,
  `date_paid` date NOT NULL,
  `station_id` int(20) NOT NULL,
  `branch_id` int(20) NOT NULL,
  `clerk_id` int(20) NOT NULL,
  `revenue_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sales_id`, `customer_name`, `amount_paid`, `date_paid`, `station_id`, `branch_id`, `clerk_id`, `revenue_id`) VALUES
(1, 'amina', 1000, '2018-02-22', 1, 1, 1, 1),
(2, 'aminata', 1000, '2018-02-22', 1, 1, 7, 8),
(3, 'fredy', 4000, '2018-02-22', 1, 1, 8, 3),
(5, 'aman', 5000, '2018-02-22', 1, 1, 1, 1),
(9, 'natasha', 1000, '2018-02-22', 1, 1, 1, 1),
(11, 'amina', 1000, '2018-02-22', 1, 1, 2, 2),
(16, 'athumani', 1000, '2018-02-22', 1, 1, 2, 2),
(20, 'maiko', 200, '2018-02-21', 1, 1, 7, 5),
(22, 'mashaka', 2000, '2018-02-22', 1, 1, 5, 3),
(23, 'jux', 1000, '2018-02-22', 1, 1, 2, 6),
(25, 'iloge', 300, '2018-02-22', 1, 1, 7, 5),
(26, 'salim', 4000, '2018-02-22', 1, 1, 1, 4),
(28, 'nelson', 500, '2018-02-22', 1, 1, 5, 7),
(29, 'juma', 3000, '2018-02-21', 1, 1, 2, 6),
(30, 'boston', 4000, '2018-02-23', 1, 1, 1, 3),
(31, 'gadson', 1000, '2018-02-23', 1, 1, 7, 4),
(32, 'mama', 2000, '2018-02-23', 1, 1, 8, 5),
(48, 'mashaka', 100, '2018-02-23', 1, 1, 1, 3),
(49, 'mage', 3000, '2018-02-23', 1, 1, 6, 8),
(50, 'amani', 5000, '2018-02-23', 1, 1, 6, 7),
(51, 'pascal', 2000, '2018-02-23', 1, 1, 7, 7),
(52, 'mange', 2000, '2018-02-23', 1, 1, 2, 4),
(53, 'sadock', 10000, '2018-02-23', 1, 1, 3, 3),
(56, 'moses', 3000, '2018-02-23', 1, 1, 5, 2),
(57, 'wewe', 4000, '2018-02-23', 1, 1, 7, 1),
(58, 'faridi', 1000, '2018-02-23', 1, 1, 5, 1),
(59, 'salim', 5000, '2018-02-24', 1, 1, 5, 6),
(60, 'ramathan', 5000, '2018-02-24', 1, 1, 2, 1),
(62, 'masha', 200, '2018-02-24', 1, 1, 7, 8),
(63, 'mamama', 3000, '2018-02-24', 1, 1, 8, 2),
(64, 'mama dokii', 4000, '2018-02-24', 1, 1, 8, 3),
(65, 'mama salome', 6000, '2018-02-24', 1, 1, 3, 7),
(66, 'hjkajkajk', 3000, '2018-02-25', 1, 1, 1, 1),
(67, 'kalhfailail', 3000, '2018-02-25', 1, 1, 2, 2),
(68, 'lhlhacjav', 3000, '2018-02-25', 1, 1, 3, 3),
(70, 'hjacjbakj', 28000, '2018-02-25', 1, 1, 5, 4),
(71, 'aacacbbklcbals', 5000, '2018-02-25', 1, 1, 7, 5),
(72, 'yjjkajadsk', 4000, '2018-02-26', 1, 1, 1, 1),
(73, 'paulo', 2500, '2018-02-26', 1, 1, 2, 2),
(74, 'naknklcank', 4000, '2018-02-26', 1, 1, 6, 2),
(75, 'uajjajdjdaj', 3500, '2018-02-26', 1, 1, 7, 6),
(76, 'nalnldlknlad', 3000, '2018-02-26', 1, 1, 7, 8),
(77, 'mkalklasdn', 2000, '2018-02-26', 1, 1, 3, 8),
(78, 'aklldalldadds', 2000, '2018-02-26', 1, 1, 6, 7),
(79, 'lakklakllak', 4000, '2018-02-26', 1, 1, 3, 1),
(80, 'lakljakl', 4000, '2018-02-26', 1, 1, 1, 6),
(81, 'jajalkdlcdk', 200, '2018-02-26', 1, 1, 5, 4),
(82, 'jkljakdjald', 20000, '2018-02-26', 1, 1, 5, 1),
(83, 'a;lcalja;a', 10000, '2018-02-26', 1, 1, 8, 4),
(84, 'kaklanklda', 3000, '2018-02-27', 1, 1, 1, 1),
(85, 'jjanan;a', 4000, '2018-02-27', 1, 1, 3, 5),
(86, 'nalnana;', 3200, '2018-02-27', 1, 1, 5, 2);

-- --------------------------------------------------------

--
-- Table structure for table `station`
--

CREATE TABLE `station` (
  `station_id` int(20) NOT NULL,
  `station_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `station_location` varchar(50) COLLATE utf8_bin NOT NULL,
  `date_created` date NOT NULL,
  `client_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `station`
--

INSERT INTO `station` (`station_id`, `station_name`, `station_location`, `date_created`, `client_id`) VALUES
(1, 'HALMASHAURI YA WILAYA YA IKWIRIRI', 'RUFIJI', '2018-02-21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `user_role_id` int(11) DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `user_role_id`, `first_name`, `last_name`, `email`, `password`) VALUES
(1, 1, 'josh', 'josh', 'josh@gmail.com', '0192023a7bbd73250516f069df18b500'),
(2, 2, 'web', 'tech', 'webtech@gmail.com', '3d68b18bd9042ad3dc79643bde1ff351');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_role`
--

CREATE TABLE `tbl_user_role` (
  `id` int(11) NOT NULL,
  `user_role` varchar(100) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_user_role`
--

INSERT INTO `tbl_user_role` (`id`, `user_role`) VALUES
(1, 'admin'),
(2, 'client'),
(3, 'accountant');

-- --------------------------------------------------------

--
-- Structure for view `all_sales_records`
--
DROP TABLE IF EXISTS `all_sales_records`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_sales_records`  AS  select `sales`.`sales_id` AS `sales_id`,`sales`.`customer_name` AS `customer_name`,`sales`.`amount_paid` AS `amount_paid`,`sales`.`date_paid` AS `date_paid`,`revenue_category`.`revenue_name` AS `revenue_name`,concat(`clerk`.`first_name`,' ',`clerk`.`last_name`) AS `clerk_name`,`branch`.`branch_name` AS `branch_name`,`station`.`station_name` AS `station_name` from ((((`clerk` join `sales` on((`clerk`.`clerk_id` = `sales`.`clerk_id`))) join `revenue_category` on((`sales`.`revenue_id` = `revenue_category`.`revenue_id`))) join `branch` on((`sales`.`branch_id` = `branch`.`branch_id`))) join `station` on((`sales`.`station_id` = `station`.`station_id`))) order by `sales`.`sales_id` ;

-- --------------------------------------------------------

--
-- Structure for view `clerk_amount_collected_today`
--
DROP TABLE IF EXISTS `clerk_amount_collected_today`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `clerk_amount_collected_today`  AS  select concat(`clerk`.`first_name`,' ',`clerk`.`last_name`) AS `clerk_name`,sum(`sales`.`amount_paid`) AS `sum(amount_paid)` from (`sales` join `clerk` on((`sales`.`clerk_id` = `clerk`.`clerk_id`))) where (`sales`.`date_paid` = curdate()) group by concat(`clerk`.`first_name`,' ',`clerk`.`last_name`) ;

-- --------------------------------------------------------

--
-- Structure for view `revenue_category_amount`
--
DROP TABLE IF EXISTS `revenue_category_amount`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `revenue_category_amount`  AS  select `revenue_category`.`revenue_name` AS `revenue_name`,sum(`sales`.`amount_paid`) AS `total_amount` from (`sales` join `revenue_category` on((`sales`.`revenue_id` = `revenue_category`.`revenue_id`))) group by `revenue_category`.`revenue_name` ;

-- --------------------------------------------------------

--
-- Structure for view `revenue_category_today_sales`
--
DROP TABLE IF EXISTS `revenue_category_today_sales`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `revenue_category_today_sales`  AS  select `revenue_category`.`revenue_name` AS `revenue_name`,sum(`sales`.`amount_paid`) AS `amount_paid` from (`sales` join `revenue_category` on((`sales`.`revenue_id` = `revenue_category`.`revenue_id`))) where (`sales`.`date_paid` = curdate()) group by `revenue_category`.`revenue_name` ;

-- --------------------------------------------------------

--
-- Structure for view `revenue_id_amount`
--
DROP TABLE IF EXISTS `revenue_id_amount`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `revenue_id_amount`  AS  select `sales`.`revenue_id` AS `revenue_id`,sum(`sales`.`amount_paid`) AS `amount_paid` from `sales` where (`sales`.`date_paid` = curdate()) group by `sales`.`revenue_id` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branch_id`),
  ADD KEY `station_id` (`station_id`);

--
-- Indexes for table `clerk`
--
ALTER TABLE `clerk`
  ADD PRIMARY KEY (`clerk_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `station_id` (`station_id`,`branch_id`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`client_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `revenue_category`
--
ALTER TABLE `revenue_category`
  ADD PRIMARY KEY (`revenue_id`),
  ADD UNIQUE KEY `revenue_name` (`revenue_name`),
  ADD KEY `station_id` (`station_id`,`branch_id`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sales_id`),
  ADD KEY `station_id` (`station_id`,`branch_id`,`clerk_id`,`revenue_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `revenue_id` (`revenue_id`),
  ADD KEY `clerk_id` (`clerk_id`);

--
-- Indexes for table `station`
--
ALTER TABLE `station`
  ADD PRIMARY KEY (`station_id`),
  ADD KEY `client_id` (`client_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user_role`
--
ALTER TABLE `tbl_user_role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrator`
--
ALTER TABLE `administrator`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `branch_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `clerk`
--
ALTER TABLE `clerk`
  MODIFY `clerk_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `client_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `revenue_category`
--
ALTER TABLE `revenue_category`
  MODIFY `revenue_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `station`
--
ALTER TABLE `station`
  MODIFY `station_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_user_role`
--
ALTER TABLE `tbl_user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `branch`
--
ALTER TABLE `branch`
  ADD CONSTRAINT `branch_ibfk_1` FOREIGN KEY (`station_id`) REFERENCES `station` (`station_id`);

--
-- Constraints for table `clerk`
--
ALTER TABLE `clerk`
  ADD CONSTRAINT `clerk_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`),
  ADD CONSTRAINT `clerk_ibfk_3` FOREIGN KEY (`station_id`) REFERENCES `station` (`station_id`);

--
-- Constraints for table `client`
--
ALTER TABLE `client`
  ADD CONSTRAINT `client_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `administrator` (`admin_id`);

--
-- Constraints for table `revenue_category`
--
ALTER TABLE `revenue_category`
  ADD CONSTRAINT `revenue_category_ibfk_1` FOREIGN KEY (`station_id`) REFERENCES `station` (`station_id`),
  ADD CONSTRAINT `revenue_category_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`);

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`station_id`) REFERENCES `station` (`station_id`),
  ADD CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`branch_id`),
  ADD CONSTRAINT `sales_ibfk_3` FOREIGN KEY (`clerk_id`) REFERENCES `clerk` (`clerk_id`),
  ADD CONSTRAINT `sales_ibfk_4` FOREIGN KEY (`revenue_id`) REFERENCES `revenue_category` (`revenue_id`);

--
-- Constraints for table `station`
--
ALTER TABLE `station`
  ADD CONSTRAINT `station_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
