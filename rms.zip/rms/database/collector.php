$app->post('/api/colector/add', fuction(Request $request, Response $response){
	$collector_code = request->getParam('$collector_code');

})