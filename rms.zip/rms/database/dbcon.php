<?php
$con=mysqli_connect("localhost","root","josh","rms") ;

function getUserAccessRoleByID($id)
{
    global $con;

    $query = "select user_role from tbl_user_role where  id = ".$id;

    $rs = mysqli_query($con,$query);
    $row = mysqli_fetch_assoc($rs);

    return $row['user_role'];
}
?>
