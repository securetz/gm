<?php
header('location:admin');
?>