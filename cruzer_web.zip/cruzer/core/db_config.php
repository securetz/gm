<?php
 
/*
 * All database connection variables
 */
 
define('DB_USER', "jetbench_admin"); // db user
define('DB_PASSWORD', "Asdf!234"); // db password (mention your db password here)
define('DB_DATABASE', "jetbench_taxi"); // database name
define('DB_SERVER', "localhost"); // db server
?>