<?php

/*!
 * ifsoft.co.uk engine v1.0
 *
 * http://ifsoft.com.ua, http://ifsoft.co.uk
 * qascript@ifsoft.co.uk
 *
 * Copyright 2012-2016 Demyanchuk Dmitry (https://vk.com/dmitry.demyanchuk)
 */

?>

<?php

    if (APP_DEMO) {

        ?>

        <div class="card blue-grey lighten-2">
            <div class="card-content white-text">
                <span class="card-title">Warning! Enabled demo version mode! The changes you've made will not be saved.</span>
            </div>
        </div>

        <?php
    }
?>