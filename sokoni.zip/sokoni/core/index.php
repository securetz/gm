<?php

header("Location: /");
