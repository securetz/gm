<?php
/**
 * Created by PhpStorm.
 * User: Администратор
 * Date: 05.06.2016
 * Time: 13:12
 */

?>

<div class="tosContent">

    <div class="tosHeader">Agreement and terms of use <?php echo APP_TITLE; ?></div>
    <p>This Agreement regulates the relations between the Administration of the information resource «<?php echo APP_TITLE; ?>» and an individual who seeks and disseminates information on this resource.</p>
    <p>Information resource «<?php echo APP_TITLE; ?>» not a mass media, the Administration of a resource does not edit the information posted and is not responsible for its content.</p>
    <p>A user posting information on the resource «<?php echo APP_TITLE; ?>», independently represents and protects its interests arising in connection with the placement of the specified information, in relations with third parties.</p>

    <p>The text you have to write your own, because one person has forbidden me to use "words" :) I'm sorry, but I have no right to write the text in this section :) Now I will write only code :)
        <br>
        <br>
        Say "thank you" to this good man :)
        <br>
        <br>
        Please edit the file: terms/terms_content.php
    </p>

</div>
