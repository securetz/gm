<?php

    /*!
     * ifsoft.co.uk v1.0
     *
     * http://ifsoft.com.ua, http://ifsoft.co.uk
     * raccoonsquare@gmail.com
     *
     * Copyright 2012-2018 Demyanchuk Dmitry (raccoonsquare@gmail.com)
     */

$C['GCM_NOTIFY_VIDEO_COMMENT_REPLY'] = 21;
$C['GCM_NOTIFY_VIDEO_COMMENT'] = 22;
$C['GCM_NOTIFY_VIDEO_LIKE'] = 23;

$C['GCM_NOTIFY_REFERRAL'] = 24;

$C['GCM_NOTIFY_MATCH'] = 25;

$C['GCM_NOTIFY_TYPING_START'] = 27;
$C['GCM_NOTIFY_TYPING_END'] = 28;