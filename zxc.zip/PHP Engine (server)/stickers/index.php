<?php

/*!
 * ifsoft.co.uk v1.0
 *
 * http://ifsoft.com.ua, http://ifsoft.co.uk
 * raccoonsqaure@gmail.com
 *
 * Copyright 2012-2018 Demyanchuk Dmitry (raccoonsqaure@gmail.com)
 */

header("Location: /");

