<?php
session_start();
require_once ('database/dbcon.php');

if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location:sample.php?lmsg=true');
    exit;
}
if (!isset($_SESSION['CREATED'])){
    $_SESSION['CREATED']=time();
}
elseif (time()- $_SESSION['CREATED'] > 300){
    header('location:index.php');
    session_destroy();
    die("your session has expired");
}

require_once('header.php');
require_once('left_sidebar.php');

?>

    <div class="content">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a style="text-decoration: none">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Branches</li>
            </ol>
            <div class="col-md-12">
                <div class="card">
                    <div class="alert alert-info text-center" style="padding-top: 1px">
                        <span>LIST OF BRANCHES</span>
                    </div>
                    <hr>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover table-striped table-bordered">
                            <thead>
                            <tr class="success">
                                <th>BRANCH ID</th>
                                <th>BRANCH NAME</th>
                                <th>DATE CREATED</th>
                                <th>STATION ID</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <?php
                                $query = "SELECT branch_id, branch_name,date_created,station_id FROM branch";//select query for viewing users.
                                $run = mysqli_query($con, $query);//here run the sql query.

                                while ($row = mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
                                {
                                $branch_id = $row[0];
                                $branch_name = $row[1];
                                $date = $row[2];
                                $stat_id = $row[3];
                                ?>
                            </tr>
                            <tr>
                                <!--here showing results in the table -->
                                <td><?php echo $branch_id; ?></td>
                                <td><?php echo $branch_name; ?></td>
                                <td><?php echo $date; ?></td>
                                <td><?php echo $stat_id; ?></td>
                            </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
require_once('footer.php');
?>