<?php
require_once ('database/dbcon.php');
$sql =  "SELECT revenue_name, sum(amount_paid) as total_amount from sales inner join revenue_category on 
sales.revenue_id=revenue_category.revenue_id WHERE date(date_paid)=CURRENT_DATE GROUP by revenue_name ORDER BY total_amount  DESC ;";
$query = mysqli_query($con,$sql);
while($result = mysqli_fetch_array($query))
{
  $rows[]=array("c"=>array("0"=>array("v"=>$result['revenue_name'],"f"=>NULL),"1"=>array("v"=>(int)$result['total_amount'],"f" =>NULL)));
  
}

echo $format = '{
"cols":
[
{"id":"","label":"Name","pattern":"","type":"string"},
{"id":"","label":"Amount","pattern":"","type":"number"}
],
"rows":'.json_encode($rows).'}';

	

?>








