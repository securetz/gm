<?php
$con=mysqli_connect("localhost","dedicate_root","###@webtechnologies","dedicate_rms") or die("connection error") ;

function getUserAccessRoleByID($id)
{
    global $con;

    $query = "select user_role from tbl_user_role where  id = ".$id;

    $rs = mysqli_query($con,$query);
    $row = mysqli_fetch_assoc($rs);

    return $row['user_role'];
}
?>
