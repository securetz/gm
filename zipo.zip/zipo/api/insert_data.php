<?php
require "DbConnect.php";
$sales_id ="1";

$customer_name = $_POST["customer_name"];

$amount_paid = $_POST["amount_paid"];

date_default_timezone_set('Africa/Dar_es_Salaam');
$date_paid = date("Y-m-d H:i:s");

$transaction_id = $_POST["transaction_id"];

$station_id =$_POST["station_id"];

$branch_id =$_POST["branch_id"];

$clerk_id = $_POST["clerk_id"];

$revenue_id = $_POST["revenue_id"];

$sql = "INSERT INTO sales VALUES('','$customer_name','$amount_paid','$date_paid','$transaction_id','$station_id','$branch_id','$clerk_id','$revenue_id')";
if($customer_name != null && $amount_paid != null &&  $revenue_id != null ){

    $result = mysqli_query($con, $sql);
    if($result == true){
        echo "One row Affected";
    }
    else
        echo "Error in Connection" .mysqli_error($con);

}

?>