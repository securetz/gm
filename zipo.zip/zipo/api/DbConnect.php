<?php
$servername = "localhost";
$username = "dedicate_root";
$password = "###@webtechnologies";
$database = "dedicate_rms";

$con = new mysqli($servername, $username, $password, $database);


if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}