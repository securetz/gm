<?php
session_start();

require_once ('database/dbcon.php');

if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location:index.php?lmsg=true');
    exit;
}
if (!isset($_SESSION['CREATED'])){
    $_SESSION['CREATED']=time();
}
elseif (time()- $_SESSION['CREATED'] > 300){
    header('location:index.php');
    session_destroy();
    die("your session has expired");
}

if (isset($_POST['submit'])) {

    if(!empty($_POST['first_name']) && !empty($_POST['last_name'])&& !empty($_POST['email'])&& !empty($_POST['password'])){
    $f_name = $_POST['first_name'];
    $l_name = $_POST['last_name'];
    $salt = "7jdkbah3-498329jkb4239u29u3bm";
    $pass = $_POST['password'].$salt;
    $pass = sha1($_POST['password']);
    $email = $_POST['email'];
    $contact = $_POST['contact'];


    $sql = "INSERT INTO administrator (first_name,last_name,password,email,contact) VALUES ('$f_name','$l_name','$pass', '$email', '$contact')";

    if (mysqli_query($con, $sql) )  {

        $message = "New Admin Added Successfully";
       //  header('Location:manage_admin.php');
    } else {
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
    }
 }
}
require_once ('header.php');
require_once ('left_sidebar.php');

?>

        <div class="content">
            <div class="container-fluid">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a style="text-decoration: none">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">Add New Administrator</li>
                </ol>
                <!-- Example DataTables Card-->

            <div class="row centered-form">
                <div class="col-md-12 ">
                    <div class="panel panel-default">
                        <div class="message btn-success text-center"><?php if (isset($message)) {
                                echo $message;
                            } ?></div>
                        <br/>
                        <div class="header clearfix">
                            <a href="manage_admin.php" class="btn btn-primary pull-right">View Admins</a>
                        </div>
                        <hr>
                        <div class="panel-heading">
                            <h3 class="panel-title">Please add Admin information</h3>
                        </div>
                        <div class="panel-body">
                            <form method="post" autocomplete="off" action="create_admin.php">
                                <div class="row">
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <input type="text" name="first_name" id="firstname"
                                               required    class="form-control input-sm"
                                                   placeholder="First Name" >
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <input type="text" name="last_name" id="lastname"
                                                   class="form-control input-sm" required
                                                   placeholder="last name">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <input type="password" name="password" id="password" autocomplete="new-password"
                                              required     class="form-control input-sm"  placeholder="Password">
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <input type="email" name="email" id="address" autocomplete="new-email"
                                             required class="form-control input-sm" placeholder="Email">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <input type="tel" name="contact" id="contact" required
                                                   class="form-control input-sm"
                                                   placeholder="contact">
                                        </div>
                                    </div>
                                </div>
                                <input type="submit" name="submit" value="Add" class="btn btn-primary">

                            </form>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>

<?php require_once ('footer.php');?>