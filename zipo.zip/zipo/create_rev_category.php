<?php

session_start();

require_once ('database/dbcon.php');

if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location:index.php?lmsg=true');
    exit;
}
if (!isset($_SESSION['CREATED'])){
    $_SESSION['CREATED']=time();
}
elseif (time()- $_SESSION['CREATED'] > 300){
    header('location:index.php');
    session_destroy();
    die("your session has expired");
}

if (isset($_POST['submit'])) {

    if ( !empty($_POST['revenue_name'])&& !empty($_POST['date_created'])&& !empty($_POST['station_id'])&& !empty($_POST['branch_id'])) {
        $rev_name = $_POST['revenue_name'];
        $date = $_POST['date_created'];
        $station_id = $_POST['station_id'];
        $branch_id = $_POST['branch_id'];

        $sql = "INSERT INTO revenue_category (revenue_name, date_created, station_id, branch_id)
         VALUES ('$rev_name','$date','$station_id','$branch_id')";
        if (mysqli_query($con, $sql)) {

            $message = "New Revenue Category Added Successfully";

        } else {
            $error= "ERROR: Could not be able to execute";
        }
    }

}
require_once('header.php');
require_once('left_sidebar.php');
?>

    <div class="content">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a style="text-decoration: none">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Add New Category </li>
            </ol>
            <!-- Example DataTables Card-->

            <div class="row centered-form">
                <div class="col-md-12 ">
                    <div class="panel panel-default">
                        <div class="message btn-success text-center"><?php if (isset($message)) {
                                echo $message;
                            } ?></div>
                        <br>
                        <div class="message btn-danger text-center"><?php if (isset($error)) {
                                echo $error;
                            } ?></div>
                        <div class="header clearfix">
                            <a href="manage_rev_categories.php" class="btn btn-primary pull-right">View Categories</a>
                        </div>
                        <hr>
                        <div class="panel-heading">
                            <h3 class="panel-title">Please add New Revenue Category</h3>
                        </div>
                        <div class="panel-body">
                            <form method="post" autocomplete="off" action="create_rev_category.php">
                                <div class="row">
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <input type="text" name="revenue_name" id="rev_name"
                                                   class="form-control input-sm" required
                                                   placeholder="Revenue Name ">
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <input type="date" name="date_created" id="date"
                                                   class="form-control input-sm" required
                                                   placeholder="Date ">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <label >
                                                <select name="station_id" class="c-form-profession form-control" id="c-form-profession" required>
                                                    <option value="">Station</option>
                                                    <option>1</option>
                                                </select>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <label >
                                                <select name="branch_id" class="c-form-profession form-control" id="c-form-profession" required>
                                                    <option value="">Branch</option>
                                                    <option>1</option>
                                                </select>
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <input type="submit" name="submit" value="Add" class="btn btn-primary">

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
require_once('footer.php');
?>