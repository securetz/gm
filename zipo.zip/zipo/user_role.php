<?php

session_start();

require_once ('database/dbcon.php');

if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location:index.php?lmsg=true');
    exit;
}
if (!isset($_SESSION['CREATED'])){
    $_SESSION['CREATED']=time();
}
elseif (time()- $_SESSION['CREATED'] > 300){
    header('location:index.php');
    session_destroy();
    die("your session has expired");
}

if (isset($_POST['submit'])) {

    if ( !empty($_POST['user_role'])) {
        $user_role = $_POST['user_role'];

        $sql = "INSERT INTO user_roles (user_role)
         VALUES ('$user_role')";
        if (mysqli_query($con, $sql)) {

            $message = "New User Role Added Successfully";

        } else {
            $error= "ERROR: Could not be able to execute";
        }
    }

}
require_once('header.php');
require_once('left_sidebar.php');
?>

    <div class="content">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a style="text-decoration: none">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Add New Role </li>
            </ol>
            <!-- Example DataTables Card-->

                <div class="row centered-form">
                    <div class="col-md-12 " style="padding-left: 1cm">
                        <div class="panel panel-default">
                            <div class="message btn-success text-center"><?php if (isset($message)) {
                                    echo $message;
                                } ?></div>
                            <div class="message btn-danger text-center"><?php if (isset($error)) {
                                    echo $error;
                                } ?></div>
                            <br>
                            <div class="header clearfix">
                                <a href="view_user_roles.php" class="btn btn-primary pull-right">View Users Roles</a>
                            </div>
                            <hr>
                            <div class="panel-heading">
                                <h3 class="panel-title">Please add New Role information</h3>
                            </div>
                            <div class="panel-body">
                                <form method="post" autocomplete="off" action="user_role.php">
                                    <div class="row">
                                        <div class="col-xs-6 col-sm-6 col-md-6">
                                            <div class="form-group">
                                                <input type="text" name="user_role" id="role"
                                                       class="form-control input-sm" required
                                                       placeholder="Name of Role ">
                                            </div>
                                        </div>
                                    </div>
                                    <input type="submit" name="submit" value="Add" class="btn btn-primary">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
require_once('footer.php');
?>