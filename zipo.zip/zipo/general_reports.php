<?php
session_start();

require_once ('database/dbcon.php');

if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location:index.php?lmsg=true');
    exit;
}
if (!isset($_SESSION['CREATED'])){
    $_SESSION['CREATED']=time();
}
elseif (time()- $_SESSION['CREATED'] > 600){
    header('location:index.php');
    session_destroy();
    die("your session has expired");
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1,chrome=1"/>
    <meta http-equiv="refresh" content="300">
    <link rel="icon" href="images/favicon.ico">

    <title>RMS | Dashboard </title>
    <script src="js/ie-emulation-modes-warning.js"></script>
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>
    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet"/>
    <link type="text/css" href="vendor/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" href="vendor/css/bootstrap-table.css" rel="stylesheet">
    <link type="text/css" href="vendor/css/font-awesome.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <!-- Bootstrap core CSS-->
    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="vendor/css/sb-admin.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <link href="report/bootstrap/css/sb-admin-2.css" rel="stylesheet">
    <link href="report/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- range css limks -->
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" media="all"
          href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/2.1.27/daterangepicker.css"/>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/2.1.27/daterangepicker.css"
          rel="stylesheet" media="screen">
    <style type="text/css">
        .demo1 {
            position: relative;
        }

        .demo1 i {
            position: absolute;
            bottom: 10px;
            right: 20px;
            top: auto;
            cursor: pointer;
        }

    </style>
</head>
<body>
<div class="wrapper">
    <div class="sidebar" data-color="blue" data-image="assets/img/sidebar-5.jpg">

        <!--Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
            Tip 2: you can also add an image using data-image tag-->

        <div class="sidebar-wrapper">
            <div class="logo">
                <h5>Revenue Management System</h5>
            </div>
            <ul class="nav">
                <li class="active">
                    <a href="dashboard.php">
                        <i class="pe-7s-home"></i>
                        <p>DashBoard</p>
                    </a>
                </li>
                <li class="active">
                    <a href="general_sales.php">
                        <i class="pe-7s-server"></i>
                        <p>General Sales</p>
                    </a>
                </li>
                <li class="active">
                    <a href="stations.php">
                        <i class="pe-7s-note2"></i>
                        <p>stations</p>
                    </a>
                </li>
                <li class="active">
                    <a href="branches.php">
                        <i class="pe-7s-news-paper"></i>
                        <p> BRANCHES</p>
                    </a>
                </li>
                <?php
                //only visible to admin
                if ($_SESSION['user_role_id'] == 1) {
                    ?>
                    <li class=" active nav-item " data-toggle="tooltip" data-placement="right" title="Components">
                        <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse"
                           href="#collapseComponents"
                           data-parent="#exampleAccordion">
                            <i class="pe-7s-config"></i>
                            <p>Management</p>
                        </a>
                        <ul class="sidenav-second-level collapse" id="collapseComponents">
                            <li class="active">
                                <a href="manage_admin.php">
                                    <i class="pe-7s-id"></i>
                                    <p>Admin</p>
                                </a>
                            </li>
                            <li class="active">
                                <a href="manage_client.php">
                                    <i class="pe-7s-id"></i>
                                    <p>Client</p>
                                </a>
                            </li>
                            <li class="active">
                                <a href="manage_station.php">
                                    <i class="pe-7s-diamond"></i>
                                    <p>Station</p>
                                </a>
                            </li>
                            <li class="active">
                                <a href="manage_branches.php">
                                    <i class="pe-7s-way"></i>
                                    <p>Branches</p>
                                </a>
                            </li>
                            <li class="active">
                                <a href="manage_rev_categories.php">
                                    <i class="pe-7s-wallet"></i>
                                    <p>Categories</p>
                                </a>
                            </li>
                            <li class="active">
                                <a href="manage_clerks.php">
                                    <i class="pe-7s-settings"></i>
                                    <p>Clerks</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php
                }
                ?>
                <li class="active">
                    <a href="general_reports.php">
                        <i class="pe-7s-albums"></i>
                        <p>General Reports</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a>
                                <i class="fa fa-dashboard"></i>
                                <p class="hidden-lg hidden-md">Dashboard</p>
                            </a>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active">
                            <a>
                                <p>
                                    <?php echo $_SESSION['email']; ?>
                                </p>
                            </a>
                        </li>
                        <li class="active">
                            <a href="logout.php">
                                <p>Log out</p>
                            </a>
                        </li>
                        <li class="separator hidden-lg"></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="content">
            <div class="container-fluid"><!---start of container for maintaining fluid and footer position-->
                <!-- Wrap all page content here -->
                <div id="wrap">
                    <div class="container">
                        <div class="col-lg-10 col-md-10 col-sm-10">
                            <div class="col-md-4 col-md-4 demo1">

                                <h5>Select the date to filter records</h5>
                                <input id="config-demo1" class="form-control text-center" title="">
                                <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>

                            </div>
                            <script type="text/javascript">
                                $(function () {

                                    function cb(start, end) {
                                        $('#reportrange1').find('span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
                                    }

                                    cb(moment().subtract(29, 'days'), moment());

                                    $('#reportrange1').daterangepicker({
                                        ranges: {
                                            'Today': [moment(), moment()],
                                            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                                            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                                            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                                            'This Month': [moment().startOf('month'), moment().endOf('month')],
                                            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                                        }
                                    }, cb);

                                });
                            </script>
                        </div>

                    </div>
                    <div class="col-lg-1 col-md-1 col-sm-1"></div>
                </div>
                <hr>
                <div class="col-lg-1 col-md-1 col-sm-1"></div>
                <div class="col-lg-10 col-md-10 col-sm-10">
                    <div class="loader1 text-center"></div>
                    <div class="response"></div>
                </div>
                <div class="col-lg-1 col-md-1 col-sm-1"></div>

            </div><!---end of container for maintaining fluid and footer position-->
        </div>
        <footer class="panel-footer">
            <div class="container-fluid">
                <p class="copyright pull-right">
                    Copyright &copy;
                    <script>document.write(new Date().getFullYear())</script>
                    WebTechnologies
                </p>
            </div>
        </footer>
    </div>
</div>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.21.0/moment.min.js"></script>
<script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/2.1.27/daterangepicker.js"></script>
<script type="text/javascript">
    $(document).ready(function () {

        $('.demo1 i').click(function () {
            $(this).parent().find('input').click();
        });

        updateConfig();

        function updateConfig() {
            var options = {};
            options.opens = "right";
            options.ranges = {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            };

            $('#config-demo1').daterangepicker(options, function (start, end, label) {
                var startDate = start.format('YYYY-MM-DD');
                var endDate = end.format('YYYY-MM-DD');
                passDate(startDate, endDate);
                //console.log('New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')');

            });

        }

    });

    function passDate(startDate, endDate) {
        $('.loader1').show();
        //date = d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
        $.ajax({
            type: 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url: 'range.php', // the url where we want to POST
            data: 'startDate=' + startDate + '&endDate=' + endDate // our data object
        })
        // using the done promise callback
            .done(function (data) {
                $('.loader1').hide();
                // log data to the console so we can see
                $('.response').html(data);
                // here we will handle errors and validation messages
            });
    }

</script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="report/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>

