$(document).ready(function(){
	$.ajax({
		url: "http://dedicatedhosting.co.tz/ikwiriri/all_sales_data.php",
		method: "GET",
		success: function(data) {
			console.log(data);
			var rms = [];
			var revenue_category_amount = [];

			for(var i in data) {
				rms.push("" + data[i].revenue_name);
				revenue_category_amount.push(data[i].total_amount);
			}

			var chartdata = {
				labels: rms,
				datasets : [
					{
						label: 'Total Sales',
						backgroundColor: [
						'rgba(255, 99, 132, 0.6)',
						'rgba(54, 162, 235, 0.6)',
						'rgba(255, 206, 86, 0.6)',
						'rgba(75, 192, 192, 0.6)',
						'rgba(153, 102, 255, 0.6)',
						'rgba(255, 159, 64, 0.6)',
						'rgba(255, 99, 132, 0.6)'
					  ],
						borderColor: [
						'rgba(255,99,132,1)',
						'rgba(54, 162, 235, 1)',
						'rgba(255, 206, 86, 1)',
						'rgba(75, 192, 192, 1)',
						'rgba(153, 102, 255, 1)',
						'rgba(255, 159, 64, 1)'
					  ],borderWidth: 1,
						hoverBackgroundColor: 'rgba(200, 200, 200, 1)',
						hoverBorderColor: 'rgba(200, 200, 200, 1)',
						data: revenue_category_amount
					}
				]
			};

			var ctx = $("#mycanvas");

			var barGraph = new Chart(ctx, {
				type: 'bar',
				data: chartdata
			});
		},
		error: function(data) {
			console.log(data);
		}
	});
});