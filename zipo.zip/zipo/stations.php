<?php
session_start();

require_once ('database/dbcon.php');

if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location:index.php?lmsg=true');
    exit;
}
if (!isset($_SESSION['CREATED'])){
    $_SESSION['CREATED']=time();
}
elseif (time()- $_SESSION['CREATED'] > 300){
    header('location:index.php');
    session_destroy();
    die("your session has expired");
}
require_once ('header.php');
require_once ('left_sidebar.php');

?>

    <div class="content">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a style="text-decoration: none">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Stations</li>
            </ol>
            <div class="col-md-12">
                <div class="card">
                    <div class="alert alert-info text-center" style="padding-top: 1px">
                        <span>LIST OF STATION</span>
                    </div>
                    <hr>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover table-striped table-bordered">
                            <thead>
                            <tr class="success">
                                <th>STATION ID</th>
                                <th>STATION NAME</th>
                                <th>STATION LOCATION</th>
                                <th>DATE CREATED</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <?php
                                $query="select station_id, station_name,station_location, date_created from station";//select query for viewing users.
                                $run=mysqli_query($con,$query);//here run the sql query.

                                while($row=mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
                                {
                                $station_id=$row[0];
                                $station_name=$row[1];
                                $station_location=$row[2];
                                $date=$row[3];
                                // $email=$row[4];

                                ?>
                            </tr>
                            <tr>
                                <!--here showing results in the table -->
                                <td><?php echo $station_id;  ?></td>
                                <td><?php echo $station_name;  ?></td>
                                <td><?php echo $station_location;  ?></td>
                                <td><?php echo $date;  ?></td>

                            </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
require_once ('footer.php');
?>