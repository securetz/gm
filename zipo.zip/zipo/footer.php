<footer class="panel-footer">
    <div class="container-fluid">
        <p class="copyright pull-right">Copyright &copy;
            <script>document.write(new Date().getFullYear())</script>
            WebTechnologies
        </p>
    </div>
</footer>
<script>
    $(document).ready(function () {
        $('#dataTable').DataTable();
    });
</script>
<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>
</div>
</div>

<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/css/buttons.dataTables.min.css"></script>
<!-- Page level plugin JavaScript-->
<!--<script src="vendor/datatables/jquery.dataTables.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.js"></script>  -->
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
</body>
</html>