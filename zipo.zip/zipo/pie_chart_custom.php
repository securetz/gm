<?php
require_once ('database/dbcon.php');

if (!empty($_POST['startDate']) && (!empty($_POST['endDate']))) {
    $startDate = date('Y-m-d', strtotime($_POST['startDate']));
    $endDate = date('Y-m-d', strtotime($_POST['endDate']));

$query = mysqli_query($con, 'SELECT revenue_name,sum(amount_paid) as amount_paid from sales 
 inner JOIN revenue_category category ON sales.revenue_id = category.revenue_id
 WHERE date(date_paid)  BETWEEN "' . $startDate . '" AND "' . $endDate . '" group by revenue_name');


//$query = mysqli_query($con, $sql);
    while ($result = mysqli_fetch_array($query)) {
        $rows[] = array("c" => array("0" => array("v" => $result['revenue_name'], "f" => NULL), "1" => array("v" => (int)$result['amount_paid'], "f" => NULL)));


        echo $format = '{
"cols":
[
{"id":"","label":"Name","pattern":"","type":"string"},
{"id":"","label":"Amount","pattern":"","type":"number"}
],
"rows":' . json_encode($rows) . '}';



 }
}








