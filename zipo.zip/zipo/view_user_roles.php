<?php
session_start();

require_once ('database/dbcon.php');

if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location:index.php?lmsg=true');
    exit;
}
if (!isset($_SESSION['CREATED'])){
    $_SESSION['CREATED']=time();
}
elseif (time()- $_SESSION['CREATED'] > 300){
    header('location:index.php');
    session_destroy();
    die("your session has expired");
}
require_once('header.php');
require_once('left_sidebar.php');
?>

    <div class="content">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a style="text-decoration: none">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Roles</li>
            </ol>
            <div class="col-md-12">
                <div class="card">
                    <div class="alert alert-info text-center" style="padding-top: 0.05cm">
                        <span>ROLES MANAGEMENT PANEL</span>
                    </div>
                    <div class="header clearfix">
                        <a href="manage_admin.php" class="btn btn-primary pull-right">Add New User Role</a>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover table-striped table-bordered">
                            <thead>
                            <tr CLASS="success">
                                <th>ID</th>
                                <th>USER ROLE</th>
                                <th>ACTIONS</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <?php
                                $query = "SELECT id,user_role FROM user_roles ORDER BY id";//select query for viewing users.
                                $run = mysqli_query($con, $query);//here run the sql query.

                                while ($row = mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
                                {
                                $id = $row[0];
                                $role = $row[1];
                                ?>
                            </tr>
                            <tr>
                                <!--here showing results in the table -->
                                <td><?php echo $id; ?></td>
                                <td><?php echo $role; ?></td>
                                <td>
                                    <a href='view_user_roles.php' title='View Record'
                                       data-toggle='tooltip'><span class='glyphicon glyphicon-eye-open'></span></a>
                                    <a href='#?id=' title='Update Record'
                                       data-toggle='tooltip'><span class='glyphicon glyphicon-pencil'></span></a>
                                    <a class="delete_user_role" data-user-role="<?php echo $row["id"]; ?>" href="javascript:void(0)">
                                        <i class="glyphicon glyphicon-trash"></i>
                                    </a>
                                </td>

                            </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
require_once('footer.php');
?>