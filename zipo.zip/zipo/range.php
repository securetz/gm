<?php
require_once ('database/dbcon.php');
if (!empty($_POST['startDate']) && (!empty($_POST['endDate']))) {
$startDate = date('Y-m-d', strtotime($_POST['startDate']));
$endDate = date('Y-m-d', strtotime($_POST['endDate']));

$results = mysqli_query($con, 'SELECT sum(amount_paid) AS amount_paid FROM sales 
WHERE date(date_paid) BETWEEN "' . $startDate . '" AND "' . $endDate . '"');


//$num_row=mysqli_num_rows($results);


while ($row = mysqli_fetch_array($results, MYSQLI_ASSOC)){

$sum = $row['amount_paid'];
$amount_paid = number_format($sum, 2, '.', ',');
?>
<div class="row" style="padding-left: 4cm">
    <div class="col-lg-6 col-md-6">
        <div class="panel panel-red">
            <div class="panel-heading">
                <div class="row text-center">
                    <span>TOTAL COLLECTION</span>
                </div>
            </div>
            <a>
                <div class="panel-footer text-center">
                    <span>
                        <strong>TZS
                            <span><?php echo $amount_paid ?> /=</span>
                            <?php } ?>
                            <?php } ?>
                        </strong>
                    </span>
                </div>
            </a>
        </div>
    </div>
</div>
<hr>
<div class="row">
    <div class="col-lg-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <i class="fa fa-pagelines fa-fw"></i> Collection by Revenue Category
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="table-responsive ">
                        <table class="table table-hover table-bordered " id="dataTable">
                            <thead>
                            <tr class="active">
                                <th>CATEGORY NAME</th>
                                <th>AMOUNT</th>
                            </tr>
                            </thead>
                            <?php
                            require_once ('database/dbcon.php');
                            if (!empty($_POST['startDate']) && (!empty($_POST['endDate']))) {
                            $startDate = date('Y-m-d', strtotime($_POST['startDate']));
                            $endDate = date('Y-m-d', strtotime($_POST['endDate']));

                            $results = mysqli_query($con, 'SELECT revenue_name,sum(amount_paid) as amount_paid from sales 
                            inner JOIN revenue_category category ON sales.revenue_id = category.revenue_id
                             WHERE date(date_paid)  BETWEEN "' . $startDate . '" AND "' . $endDate . '" group by revenue_name order by 
                             amount_paid desc');


                            while ($row = mysqli_fetch_array($results, MYSQLI_ASSOC)){
                            $revenue = $row['revenue_name'];
                            $amount = $row['amount_paid'];
                            $total_amount = number_format($amount, 2, '.', ',');
                                ?>
                                <tr>
                                <td><?php echo $revenue; ?></td>
                                <td>TZS <a><?php echo $total_amount ?>/=</a></td>
                                </tr>
                            <?php }
                            ?>
                            <?php }
                            ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <i class="fa fa-pagelines fa-fw"></i> Collection by Clerks
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="table-responsive ">
                        <table class="table table-hover table-bordered " id="dataTable">
                            <thead>
                            <tr class="active">
                                <th>CLERK NAME</th>
                                <th>AMOUNT</th>
                            </tr>
                            </thead>
                            <?php
                            require_once ('database/dbcon.php');
                            if (!empty($_POST['startDate']) && (!empty($_POST['endDate']))) {
                                $startDate = date('Y-m-d', strtotime($_POST['startDate']));
                                $endDate = date('Y-m-d', strtotime($_POST['endDate']));

                                $results = mysqli_query($con, 'SELECT concat(first_name,\' \', last_name) as clerk_name, sum(amount_paid) as 
                              amount_paid from sales inner 
                                                join clerk on sales.clerk_id=clerk.clerk_id
                             WHERE date(date_paid)  BETWEEN "' . $startDate . '" AND "' . $endDate . '" group by clerk_name order by amount_paid 
                             desc');

                                //$num_row=mysqli_num_rows($results);

                                while ($row = mysqli_fetch_array($results, MYSQLI_ASSOC)){
                                    $clerk = $row['clerk_name'];
                                    $amount = $row['amount_paid'];
                                    $total_amount = number_format($amount, 2, '.', ',');
                                    ?>
                                    <tr>
                                        <td><?php echo $clerk; ?></td>
                                        <td>TZS <a><?php echo $total_amount ?>/=</a></td>
                                    </tr>
                                <?php }
                                ?>
                            <?php }
                            ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- chart -->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
    // Load the Visualization API and the piechart package.
    google.charts.load('current', {'packages': ['corechart']});

    // Set a callback to run when the Google Visualization API is loaded.
    google.charts.setOnLoadCallback(pie_chart);

    function pie_chart() {
        var jsonData = $.ajax({
            url: "pie_chart_custom.php",
            dataType: "json",
            async: false
        }).responseText;

        // Create our data table out of JSON data loaded from server.
        // alert(jsonData);return false;
        var data = new google.visualization.DataTable(jsonData);

        // Instantiate and draw our chart, passing in some options.
        var chart = new google.visualization.PieChart(document.getElementById('piechart_div'));
        chart.draw(data, {width: 380, height: 250});
    }
</script>
