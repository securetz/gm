<?php
session_start();
require_once ('database/dbcon.php');
if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location:index.php?lmsg=true');
    exit;
}
if (!isset($_SESSION['CREATED'])){
    $_SESSION['CREATED']=time();
}
elseif (time()- $_SESSION['CREATED'] > 300){
    header('location:index.php');
    session_destroy();
    die("your session has expired");
}

if (!isset($_SESSION['CREATED'])){
    $_SESSION['CREATED']=time();
}
elseif (time()- $_SESSION['CREATED'] > 300){
    header('location:index.php');
    session_destroy();
    die("your session has expired");
}
require_once('header.php');
require_once('left_sidebar.php');
?>

    <div class="content">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a style="text-decoration: none">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Users</li>
            </ol>
            <div class="col-md-12">
                <div class="card">
                    <div class="header modal-header" style="text-align: center">
                        <h5>USER MANAGEMENT PANEL</h5>
                    </div>
                    <div class="header clearfix">
                        <a href="create_users.php" class="btn btn-primary pull-right">Add New User</a>
                    </div>
                    <div class="content table-responsive table-full-width">
                        <table class="table table-hover table-striped table-bordered">
                            <thead>
                            <tr>
                                <th class="info">USER ID</th>
                                <th class="info">USER ROLE ID</th>
                                <th class="info">FIRST NAME</th>
                                <th class="info">LAST NAME</th>
                                <th class="info">EMAIL</th>
                                <th class="info">ACTIONS</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <?php
                                $query = "SELECT id,user_role_id, first_name,last_name, email FROM users";//select query for viewing users.
                                $run = mysqli_query($con, $query);//here run the sql query.

                                while ($row = mysqli_fetch_array($run))//while look to fetch the result and store in a array $row.
                                {
                                $id = $row[0];
                                $role_id = $row[1];
                                $first_name = $row[2];
                                $last_name = $row[3];
                                $email = $row[4];
                                ?>
                            </tr>
                            <tr>
                                <!--here showing results in the table -->
                                <td><?php echo $id; ?></td>
                                <td><?php echo $role_id; ?></td>
                                <td><?php echo $first_name; ?></td>
                                <td><?php echo $last_name; ?></td>
                                <td><?php echo $email; ?></td>
                                <td>
                                    <a href='#?id=' title='View Record'
                                       data-toggle='tooltip'><span class='glyphicon glyphicon-eye-open'></span></a>
                                    <a href='#?id=' title='Update Record'
                                       data-toggle='tooltip'><span class='glyphicon glyphicon-pencil'></span></a>
                                    <a class="delete_user" data-user-id="<?php echo $row["id"]; ?>" href="javascript:void(0)">
                                        <i class="glyphicon glyphicon-trash"></i>
                                    </a>

                            </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
require_once('footer.php');
?>