<?php

session_start();

require_once ('database/dbcon.php');

if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location:index.php?lmsg=true');
    exit;
}
if (!isset($_SESSION['CREATED'])){
    $_SESSION['CREATED']=time();
}
elseif (time()- $_SESSION['CREATED'] > 300){
    header('location:index.php');
    session_destroy();
    die("your session has expired");
}

if (isset($_POST['submit'])) {

    if (!empty($_POST['station_name']) && !empty($_POST['station_location']) && !empty($_POST['date_created']) && !empty($_POST['client_id'])) {
        $stat_name = $_POST['station_name'];
        $station_loc = $_POST['station_location'];
        $date = $_POST['date_created'];
        $client_id = $_POST['client_id'];

        $sql = "INSERT INTO station (station_name, station_location, date_created, client_id)
         VALUES ('$stat_name','$station_loc','$date','$client_id')";
        if (mysqli_query($con, $sql)) {

            $message = "New  Station Added Successfully";

        } else {
            $error = "ERROR: Could not be able to execute";
        }
    }

}
require_once('header.php');
require_once('left_sidebar.php');
?>

    <div class="content">
        <div class="container-fluid">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a style="text-decoration: none">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Add New Station</li>
            </ol>
            <!-- Example DataTables Card-->

            <div class="row centered-form">
                <div class="col-md-12 ">
                    <div class="panel panel-default">
                        <div class="message btn-success text-center"><?php if (isset($message)) {
                                echo $message;
                            } ?></div>
                        <div class="message btn-danger text-center"><?php if (isset($error)) {
                                echo $error;
                            } ?></div>
                        <br>
                        <div class="header clearfix">
                            <a href="manage_station.php" class="btn btn-primary pull-right">View Stations</a>
                        </div>
                        <hr>
                        <div class="panel-heading">
                            <h3 class="panel-title">Please add New Station </h3>
                        </div>
                        <div class="panel-body">
                            <form method="post" autocomplete="off" action="create_station.php">
                                <div class="row">
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <input type="text" name="station_name" id="stat_name"
                                                   class="form-control input-sm" required
                                                   placeholder="Station Name ">
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <input type="text" name="station_location" id="stat_loc"
                                                   class="form-control input-sm" required
                                                   placeholder="Station Location ">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <input type="date" name="date_created" id="date"
                                                   class="form-control input-sm" required
                                                   placeholder=" Date ">
                                        </div>
                                    </div>
                                    <div class="col-xs-6 col-sm-6 col-md-6">
                                        <div class="form-group">
                                            <label>
                                                <select name="client_id" class="c-form-profession form-control"
                                                        id="c-form-profession" required>
                                                    <option value="">Client ID</option>
                                                    <option>1</option>
                                                </select>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <input type="submit" name="submit" value="Add" class="btn btn-primary">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
require_once('footer.php');
?>