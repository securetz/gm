<?php
require('database/dbcon.php');
$id = $_GET['id'];

if (isset($_POST['submit'])) {
    $id = $_POST['branch_id'];
    $name = $_POST['branch_name'];
    $date = $_POST['date_created'];
    $station = $_POST['station_id'];
    $mysqli = mysqli_query($con, "UPDATE `branch` SET `branch_name` = '$name', `date_created` = '$date', 
    `station_id`='$station' WHERE `branch_id`=$id");
    header("location:manage_branches.php");
}

$run = mysqli_query($con, "SELECT * FROM `branch` WHERE `branch_id`='$id'");
$row = mysqli_fetch_assoc($run);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Using Bootstrap modal</title>

    <!-- Bootstrap Core CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="panel-body">
    <form method="post" autocomplete="off" action="update_branch.php" role="form">
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <label for="branch_id">ID</label>
                    <input  name="branch_id" id="branch"
                            class="form-control input-sm" required value="<?php echo $row['branch_id']; ?>"
                            placeholder=" ID" readonly>
                </div>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <label for="name">Branch Name</label>
                    <input  name="branch_name" id="branch_name"
                            class="form-control input-sm" required value="<?php echo $row['branch_name']; ?>"
                            placeholder=" Name">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <label for="date">Date Created</label>
                    <input type="date" min="0"  name="date_created" id="date" value="<?php echo $row['date_created']; ?>"
                       readonly    required class="form-control input-sm" placeholder="date created">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <label >
                        <select name="station_id" class="c-form-profession form-control" id="c-form-profession" required>
                            <option value="">Station ID</option>
                            <option>1</option>
                        </select>
                    </label>
                </div>
            </div>
        </div>
        <input type="submit" class="btn btn-success" name="submit" value="Update"/>&nbsp;
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
    </form>
</div>
</body>
</html>
