<?php
session_start();

require_once ('database/dbcon.php');

if (!isset($_SESSION['id'], $_SESSION['user_role_id'])) {
    header('location:index.php?lmsg=true');
    exit;
}
if (!isset($_SESSION['CREATED'])){
    $_SESSION['CREATED']=time();
}
elseif (time()- $_SESSION['CREATED'] > 300){
    header('location:index.php');
    session_destroy();
    die("your session has expired");
}
$run =mysqli_query($con,"SELECT * FROM `branch`");
require_once('header.php');
require_once('left_sidebar.php');

?>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="memberModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                </div>
                <div class="dash">
                </div>
            </div>
        </div>
    </div>
    <!-- end of Modal -->

        <div class="content">
            <div class="container-fluid">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a style="text-decoration: none">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active">Branches Management</li>
                </ol>
                <div class="col-md-12">
                    <div class="card">
                        <div class="alert alert-info text-center" style="padding-top: 1px">
                            <span>BRANCHES MANAGEMENT PANEL</span>
                        </div>
                        <hr>
                        <div class="header clearfix">
                            <a href="create_branch.php" class="btn btn-primary pull-right">Add New Branches</a>
                        </div>
                        <div class="content table-responsive table-full-width">
                            <table class="table table-hover table-striped table-bordered">
                                <thead>
                                <tr class="success">
                                    <th>BRANCH ID</th>
                                    <th>BRANCH NAME</th>
                                    <th>DATE CREATED</th>
                                    <th>STATION ID</th>
                                    <th>ACTIONS</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                while ($row = mysqli_fetch_assoc($run)):
                                    echo '<tr>';
                                    echo '<td>'.$row['branch_id'].'</td>';
                                    echo '<td>'.$row['branch_name'].'</td>';
                                    echo '<td>'.$row['date_created'].'</td>';
                                    echo '<td>'.$row['station_id'].'</td>';
                                    echo '<td>
                                          <a href=\'manage_branches.php\' title=\'View Record\'
                                           data-toggle=\'tooltip\'><span class=\'glyphicon glyphicon-eye-open\'></span>
                                           </a>
                                          <a href="javascript:void(0)"  data-toggle="modal" data-target="#exampleModal"
                                           data-whatever="'.$row['branch_id'].' ">
                                           <i class="glyphicon glyphicon-pencil"></i>
                                            </a>
                                           <a class="delete_clerk" data-clerk-id="'. $row["branch_id"].'" href="javascript:void(0)">
                                            <i class="glyphicon glyphicon-trash"></i>
                                        </a>
                                     </td>';
                                    echo '</tr>';
                                endwhile;
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <script>
        $('#exampleModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget) // Button that triggered the modal
            var recipient = button.data('whatever') // Extract info from data-* attributes
            var modal = $(this);
            var dataString = 'id=' + recipient;

            $.ajax({
                type: "GET",
                url: "update_branch.php",
                data: dataString,
                cache: false,
                success: function (data) {
                    console.log(data);
                    modal.find('.dash').html(data);
                },
                error: function(err) {
                    console.log(err);
                }
            });
        })
    </script>
<?php
require_once('footer.php');
?>