$(document).ready(function(){
    $('.delete_client').click(function(e){
        e.preventDefault();
        var status = true;
        var client_id = $(this).attr('data-client-id');
        var parent = $(this).parent("td").parent("tr");
        bootbox.dialog({
            message: "Are you sure you want to Delete ?",
            title: "<i class='glyphicon glyphicon-trash'></i> Delete !",
            buttons: {
                success: {
                    label: "No",
                    className: "btn-success",
                    callback: function() {
                        status=false;
                    }
                },
                danger: {
                    label: "Delete!",
                    className: "btn-danger",
                    callback: function() {
                        $.ajax({
                            type: 'POST',
                            url: 'delete_client.php',
                            data: 'delete='+client_id
                        })
                            .done(function(response){
                                bootbox.alert(response);
                                parent.fadeOut('slow');
                            })
                            .fail(function(){
                                bootbox.alert('Error....');
                            })
                    }
                }
            }
        });
    });
});