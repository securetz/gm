$(document).ready(function(){
    $('.delete_user').click(function(e){
        e.preventDefault();
        var status = true;
        var id = $(this).attr('data-user-id');
        var parent = $(this).parent("td").parent("tr");
        bootbox.dialog({
            message: "Are you sure you want to Delete ?",
            title: "<i class='glyphicon glyphicon-trash'></i> Delete !",
            buttons: {
                success: {
                    label: "No",
                    className: "btn-success",
                    callback: function() {
                        status=false;
                    }
                },
                danger: {
                    label: "Delete!",
                    className: "btn-danger",
                    callback: function() {
                        $.ajax({
                            type: 'POST',
                            url: 'delete_user.php',
                            data: 'delete='+id
                        })
                            .done(function(response){
                                bootbox.alert(response);
                                parent.fadeOut('slow');
                            })
                            .fail(function(){
                                bootbox.alert('Error....');
                            })
                    }
                }
            }
        });
    });
});