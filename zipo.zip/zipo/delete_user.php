<?php
include_once("database/dbcon.php");

if($_REQUEST['delete'])
{
    $sql = "DELETE FROM users WHERE id='".$_REQUEST['delete']."'";
    $resultset = mysqli_query($con, $sql) or die("database error:". mysqli_error($con));
    if($resultset)
    {
        echo "Record Deleted Successfully";
    }
}
?>