<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1,chrome=1"/>
    <meta http-equiv="refresh" content="300">
    <link rel="icon" href="images/favicon.ico">

    <title>RMS | Management</title>

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">

    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->

    <script src="js/ie-emulation-modes-warning.js"></script>
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>
    <!--  Light Bootstrap Table core CSS
    <link href="report/bootstrap/css/popup.css" rel="stylesheet"> -->

    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet"/>
    <link type="text/css" href="vendor/css/bootstrap.min.css" rel="stylesheet">
    <link type="text/css" href="vendor/css/bootstrap-table.css" rel="stylesheet">
    <link type="text/css" href="vendor/css/font-awesome.css" rel="stylesheet">

    <!-- Bootstrap core CSS-->
    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="vendor/css/sb-admin.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!-- date range report -->
    <link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" media="all" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/2.1.27/daterangepicker.css" />
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/2.1.27/daterangepicker.css" rel="stylesheet" media="screen">

    <!--<script type="text/javascript" src="http://netdna.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script> -->


    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/bootbox.min.js"></script>
    <script type="text/javascript" src="js/delete_client.js"></script>
    <script type="text/javascript" src="js/delete_clerk.js"></script>
    <script type="text/javascript" src="js/delete_user.js"></script>
    <script type="text/javascript" src="js/delete_user_role.js"></script>
    <script type="text/javascript" src="js/delete_admin.js"></script>
    <script type="text/javascript" src="js/delete_branch.js"></script>
    <script type="text/javascript" src="js/delete_station.js"></script>
    <script type="text/javascript" src="js/delete_rev_category.js"></script>
    <script  type="text/javascript" src="js/update_rev_categories.js"></script>


</head>
<body>