<?php

//setting header to json

header('Content-type: application/json');


require_once ('database/dbcon.php');
//query to get data from the table
$query = "select revenue_name, sum(amount_paid) as total_amount from sales inner join 
          revenue_category on sales.revenue_id=revenue_category.revenue_id GROUP by revenue_name;";
//execute query
$result = mysqli_query($con,$query);

//loop through the returned data
$data = array();
foreach ($result as $row) {
    $data[] = $row;
}


//now print the data
print json_encode($data);
