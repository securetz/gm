<?php
require('database/dbcon.php');
$id = $_GET['id'];

if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $role = $_POST['user_role_id'];
    $firstname = $_POST['first_name'];
    $lastname = $_POST['last_name'];
    $salt = "7jdkbah3-498329jkb4239u29u3bm";
    $pass = $_POST['password'] . $salt;
    $email = $_POST['email'];
    $pass = sha1($_POST['password']);
    $mysqli = mysqli_query($con, "UPDATE `users` SET `user_role_id`='$role',`first_name` = '$firstname', `last_name` = '$lastname', 
     `password`='$pass',`email`='$email' WHERE `id`=$id");
    header("location:view_users.php");
}

$run = mysqli_query($con, "SELECT * FROM `users` WHERE `id`='$id'");
$row = mysqli_fetch_assoc($run);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Using Bootstrap modal</title>

    <!-- Bootstrap Core CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="panel-body">
    <form method="post" autocomplete="off" action="update_users.php" role="form">
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <label for="ID">ID</label>
                    <input  name="id" id="id"
                            class="form-control input-sm" required value="<?php echo $row['id']; ?>"
                            placeholder="role ID" readonly>
                </div>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <label for="first_name">First Name</label>
                    <input  name="first_name" id="first_name"
                            class="form-control input-sm" required value="<?php echo $row['first_name']; ?>"
                            placeholder="First Name">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <input type="text" name="last_name" id="last_name"
                           class="form-control input-sm" required value="<?php echo $row['last_name']; ?>"
                           placeholder="last name">
                </div>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="address" autocomplete="new-email" value="<?php echo $row['email']; ?>"
                           required class="form-control input-sm" placeholder="Email">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="text" name="password" id="password"
                           required class="form-control input-sm" placeholder="Password">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-6 col-sm-6 col-md-6">
                <div class="form-group">
                    <label >
                        <select name="user_role_id" class="c-form-profession form-control" id="c-form-profession" required>
                            <option value="">Role ID</option>
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </label>
                </div>
            </div>
        </div>
        <input type="submit" class="btn btn-success" name="submit" value="Update"/>&nbsp;
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
    </form>
</div>
</body>
</html>
