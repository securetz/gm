<?php
session_start();

require_once('database/dbcon.php');


if(isset($_POST['login']))
{
    if(!empty($_POST['email']) && !empty($_POST['password']))
    {
        $email 		= mysqli_real_escape_string($con,$_POST['email']);
        $salt = "7jdkbah3-498329jkb4239u29u3bm";
        $password 	= mysqli_real_escape_string($con,$_POST['password'].$salt);
        $password = mysqli_real_escape_string($con,sha1($_POST['password']));

        $sql = "select * from users where email = '".$email."' and password = '".$password."'";
        $rs = mysqli_query($con,$sql);
        $getNumRows = mysqli_num_rows($rs);

        if($getNumRows == 1)
        {
            $getUserRow = mysqli_fetch_assoc($rs);
            unset($getUserRow['password']);

            $_SESSION = $getUserRow;

            header('location:dashboard.php');
            exit;
        }
        else
        {
            $errorMsg = "Wrong email or password";
        }
    }
}

if(isset($_GET['lmsg']) && $_GET['lmsg'] == true)
{
    $errorMsg = "Login required to access dashboard";
}

?>
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" >
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/favicon.ico">

    <title>RMS | Index</title>
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <!-- Custom fonts for this template-->
    <link href="assets/assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Custom styles for this template-->
    <link href="assets/assets/css/sb-admin.css" rel="stylesheet">
    <link href="css/web-btn-color.css" rel="stylesheet">

</head>
<body class="bg-secondary">
<div class="container">
    <div class="card card-login mx-auto mt-5">
        <div class="card-header text-center">Revenue Management System</div>
        <div class="login-headding">
            <img src="images/logo.png" height="74" width="350" class="img-fluid" alt="Responsive image">
        </div>
        <div class="card-body">
            <?php
            if(isset($errorMsg))
            {
                echo '<div class="alert alert-danger">';
                echo $errorMsg;
                echo '</div>';
                unset($errorMsg);
            }
            ?>
            <hr>
            <form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input class="form-control" id="exampleInputEmail1" name="email" type="email" placeholder="Enter email" required>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input class="form-control" id="exampleInputPassword1" name="password" type="password" placeholder="Password" required>
                </div>
                <button class="btn btn-success btn-block"  type="submit" name="login">Login</button>
            </form>

        </div>
    </div>
</div>
<!-- Bootstrap core JavaScript-->
<script src="assets/assets/vendor/jquery/jquery.min.js"></script>
<script src="assets/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Core plugin JavaScript-->
<script src="assets/assets/vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="js/ie10-viewport-bug-workaround.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="chart/js/jquery.min.js"><\/script>')</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<!-- Just to make our placeholder images work. Don't actually copy the next line! -->
<script src="js/holder.min.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="js/ie10-viewport-bug-workaround.js"></script>
</body>

</html>



