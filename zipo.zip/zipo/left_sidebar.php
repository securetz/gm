<div class="wrapper">
    <div class="sidebar" data-color="blue" data-image="assets/img/sidebar-5.jpg">

        <!--Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
            Tip 2: you can also add an image using data-image tag-->

        <div class="sidebar-wrapper">
            <div class="logo">
                <h5>Revenue Management System</h5>
            </div>
            <ul class="nav">
                <li class="active">
                    <a href="dashboard.php">
                        <i class="pe-7s-home"></i>
                        <p>DashBoard</p>
                    </a>
                </li>
                <li class="active">
                    <a href="general_sales.php">
                        <i class="pe-7s-server"></i>
                        <p>General Sales</p>
                    </a>
                </li>
                <li class="active">
                    <a href="stations.php">
                        <i class="pe-7s-note2"></i>
                        <p>Stations</p>
                    </a>
                </li>
                <li class="active">
                    <a href="branches.php">
                        <i class="pe-7s-news-paper"></i>
                        <p> Branches</p>
                    </a>
                </li>
                <?php
                //only visible to admin
                if ($_SESSION['user_role_id'] == 1) {
                ?>
                <li class=" active nav-item " data-toggle="tooltip" data-placement="right" title="Components">
                    <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse"
                       href="#collapseComponents"
                       data-parent="#exampleAccordion">
                        <i class="pe-7s-config"></i>
                        <p>Management</p>
                    </a>
                    <ul class="sidenav-second-level collapse" id="collapseComponents">
                        <li class="active">
                            <a href="manage_admin.php">
                                <i class="pe-7s-id"></i>
                                <p>Admin</p>
                            </a>
                        </li>
                        <li class="active">
                            <a href="manage_client.php">
                                <i class="pe-7s-id"></i>
                                <p>Client</p>
                            </a>
                        </li>
                        <li class="active">
                            <a href="manage_station.php">
                                <i class="pe-7s-diamond"></i>
                                <p>Station</p>
                            </a>
                        </li>
                        <li class="active">
                            <a href="manage_branches.php">
                                <i class="pe-7s-way"></i>
                                <p>Branches</p>
                            </a>
                        </li>
                        <li class="active">
                            <a href="manage_rev_categories.php">
                                <i class="pe-7s-wallet"></i>
                                <p>Categories</p>
                            </a>
                        </li>
                        <li class="active">
                            <a href="manage_clerks.php">
                                <i class="pe-7s-settings"></i>
                                <p>Clerks</p>
                            </a>
                        </li>
                    </ul>
                </li>
                    <?php
                    }
                    ?>
                <li class="active">
                    <a href="general_reports.php">
                        <i class="pe-7s-albums"></i>
                        <p>General Reports</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <div class="main-panel">
        <nav class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <a class="navbar-brand">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a>
                                <i class="fa fa-dashboard"></i>
                                <p class="hidden-lg hidden-md">Dashboard</p>
                            </a>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active">
                            <a href="logout.php">
                                <p>Log out</p>
                            </a>
                        </li>
                        <li class="separator hidden-lg"></li>
                    </ul>
                </div>
            </div>
        </nav>