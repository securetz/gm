<?php
//include_once("database/dbcon.php");
require_once ('database/dbcon.php');
if($_REQUEST['delete'])
{
    $sql = "DELETE FROM administrator WHERE admin_id='".$_REQUEST['delete']."'";
    $resultset = mysqli_query($con, $sql) or die("database error:". mysqli_error($con));
    if($resultset)
    {
        echo "Record Deleted Successfully";
    }
}
?>