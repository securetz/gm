<?php
error_reporting(0);

require_once 'include/DB_Functions.php';

$db = new DB_Functions();

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $tag = "";

    if (isset($_POST['tag'])) $tag = $_POST['tag'];

    switch ($tag) {
        case "clerkData":
            $response = $db -> getBasicData();
            echo json_encode($response);
            break;

        case "categoryData":
            $response = $db -> getRevenueCategory();
            echo json_encode($response);
            break;
    }

}

