<?php
error_reporting(0);

require_once 'include/DB_Functions.php';

$db = new DB_Functions();

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $tag = "";

    if (isset($_POST['tag'])) $tag = $_POST['tag'];

    switch ($tag) {
        case "save_collection":
            $data = $_POST;

            $response = $db -> saveCollectionData($data);
            echo $response;
            break;
    }

}

