<?php

$link=mysql_connect("localhost","root","@Webtechapp00..");
mysql_select_db("revenuedbs",$link);

class User
{

private $db;
private $db_table = "users";

public function isLoginExist($username, $password){		
			
	$query = "select * from " . $this->db_table . " where username = '$username' AND password = '$password' Limit 1";
	$row=mysql_query($query);
    $data=mysql_fetch_array($row);
	
	if($data>0)
        {
          	return true;
       	}
       	else
        {
			return false;
        }		
}

public function createNewRegisterUser($username, $password, $email){
		
	$query = "insert into users (username, password, email, created_at, updated_at) values ('$username', '$password', '$email')";
	
	$row=mysql_query($query);
	if($row>0)
        {
          	$json['success'] = 1;	
       	}
       	else
        {
			$json['success'] = 0;
        }
	return $json;
}

public function loginUsers($username, $password){
		
	$json = array();
	$canUserLogin = $this->isLoginExist($username, $password);
	if($canUserLogin){
		$json['success'] = 1;
	}else{
		$json['success'] = 0;
	}
	return $json;
}
}
?>
