<?php
		error_reporting(0);
        require_once 'include/DB_Functions.php';
		/* check connection */
		$mysqli->query("SET NAMES 'utf8'");
		$sql="SELECT name FROM manage_zone";
		$result=$mysqli->query($sql);
		while($e=mysqli_fetch_assoc($result)){
		$output[]=$e; 
		}	

		print(json_encode($output)); 
		$mysqli->close();	

		?>		
