<?php
error_reporting(0);
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $tag = "";

    if (isset($_POST['tag'])) $tag = $_POST['tag'];

    switch ($tag) {
        case "clerkData":
            $response = $db -> getBasicData();
            echo json_encode($response);
            break;

        case "categoryData":
            $response = $db -> getRevenueCategory();
            echo json_encode($response);
            break;
        case "rutiData":
            $response = $db -> getRutiData();
            echo jason_encode($response);
            break;
    }

}


//creating an array for storing the data 
//$customer = array(); 
 
//this is our sql query 
//$sql = "SELECT id, name FROM customer;";
 
//creating an statment with the query
//$stmt = $conn->prepare($sql);
 
//executing that statment
//$stmt->execute();
 
//binding results for that statment 
//$stmt->bind_result($id, $name);
 
//looping through all the records
//while($stmt->fetch()){

 //pushing fetched data in an array 
 //$temp = [
 //'id'=>$id,
 //'name'=>$name
 //];

 //pushing the array inside the hero array 
// array_push($customer, $temp);
//}

//displaying the data in json format 
//echo json_encode($customer);
