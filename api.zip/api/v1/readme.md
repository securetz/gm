JSON Request and Response

For example for registration, the input JSON request would be similar to,

{
   "operation":"register",
   "user":{
        "name":"Raj Amal",
        "email":"raj.amalw@learn2crack.com",
        "password":"rajamalw"
   }
}
and if the registration is successful, the response would be,

{
"result":"success",
"message":"User Registered Successfully !"
}
also if registration is not successful, the response would be,

{
"result": "failure",
"message": "User Already Registered !"
}
Similarly for login the request would be similar to,

{
   "operation":"login",
   "user":{
       "email":"raj.amalw@learn2crack.com",
       "password":"rajamalw"
   }
}
and if the credentials are correct, the response would be,

{
    "result": "success",
    "message": "Login Successful",
    "user": {
        "name": "Raj Amal",
        "email": "raj.amalw@learn2crack.com",
        "unique_id": "56fab5891ae0e6.72636328"
  }
}
also for failed login, the response would be,

{
"result": "failure",
"message": "Invaild Login Credentials"
}
Similarly for Change password, the request would be similar to,

{
   "operation":"chgPass",
   "user":{
       "email":"raj.amalw@learn2crack.com",
       "old_password":"rajamal",
       "new_password":"rajamalw"
   }
}
and if the change password operation is sucessful the response would be,

{
"result": "success",
"message": "Password Changed Successfully"
}
also for failed change password operation,

{
"result": "failure",
"message": "Invalid Old Password"
}
Now we have successfully created PHP API for Login Registration. Deploy it in your local Wamp or Lamp to test it using a REST client such as Postman.